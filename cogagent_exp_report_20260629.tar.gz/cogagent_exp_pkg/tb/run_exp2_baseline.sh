#!/bin/bash
# Exp2 phase-1: pass@3 BASELINE on the build cluster.
#   mode=bench  → feedback loop ON (not "test")  +  record_learning OFF (not "train")
#   TB_MAX_REPAIRS=2 → pass@3 (initial + 2 repair retries)
#   seed state → NO learned cards (clean baseline, no transfer)
# Re-establishes the cluster baseline under TB's pass@k paradigm (supersedes the
# old 1-shot cluster-test). Serial. Stops for review before the train/test split.
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
EXP="$PROJECT/tb/runs/exp2_baseline"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
log(){ echo "[exp2-base $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }

# Cases + output label are env-overridable so we can validate ONE case first
# (EXP2_CASES="build-stp" EXP2_LABEL=validate) then run the rest.
CASES="${EXP2_CASES:-build-stp build-tcc-qemu build-cython-ext compile-compcert build-linux-kernel-qemu build-initramfs-qemu build-pmars sudo-llvm-ir}"
LABEL="${EXP2_LABEL:-pass3}"
NCASE=$(echo $CASES | wc -w)

# 1) wait for Exp1 (shares docker/data — must not overlap)
E1=$(cat tb/runs/_bg/exp1-full.pid 2>/dev/null)
log "waiting for Exp1 (pid=$E1) to finish..."
while [ -n "$E1" ] && kill -0 "$E1" 2>/dev/null; do sleep 60; done
log "Exp1 finished; starting Exp2 pass@3 baseline"

# 2) cleanup + clean seed (baseline = no learned cards)
for c in $(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null); do timeout 40 docker rm -f "$c" >/dev/null 2>&1; done
sleep 3
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1 && log "seed restored (clean baseline, no transfer)" || { log "FATAL seed restore"; exit 1; }

# 3) reaper insurance (build tasks are heavy; kill >2h containers)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 7200 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill $REAPER 2>/dev/null' EXIT

# 4) pass@3 baseline — bench mode, k=3, serial
log "pass@3 [$LABEL]: $NCASE 个任务 (mode=bench, TB_MAX_REPAIRS=2, serial)"
export TB_MAX_REPAIRS=2
EXP_DIR="$EXP" bash tb/run_epoch.sh bench "$LABEL" "$CASES"
log "=== Exp2 [$LABEL] DONE — review ==="
sed 's/^/    /' "$EXP/$LABEL/results.txt" 2>/dev/null | tee -a "$SUM"

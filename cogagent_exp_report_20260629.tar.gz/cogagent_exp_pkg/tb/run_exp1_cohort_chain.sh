#!/bin/bash
# run_exp1_cohort_chain.sh — Exp1 cohort retrain experiment, autonomous: TRAIN then
# LEARNED EVAL. Baseline (3/9, no learning) already exists and is REUSED (not re-run).
#   1) run_exp1_cohort_train.sh   : 3 rounds train on the 9 cohort tasks (learning ON)
#   2) run_exp1_cohort_learned.sh : bench/pass@3 on the same 9 WITH learning
# Compare learned vs base 3/9 (and 1-shot base 0/9, learned 1/9).
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
mkdir -p "$PROJECT/tb/runs/_bg"
SUM="$PROJECT/tb/runs/exp1_cohort_chain.log"
log(){ echo "[cohort-chain $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }

log "=== EXP1 COHORT RETRAIN CHAIN START (B: clean retrain, current fixed system) ==="
log ">>> Phase 1/2: TRAIN (3 rounds, 9 cohort tasks)"
bash tb/run_exp1_cohort_train.sh || { log "FATAL: cohort train failed"; exit 1; }
log ">>> Phase 1/2 TRAIN done"

log ">>> Phase 2/2: LEARNED EVAL (bench/pass@3, WITH learning)"
bash tb/run_exp1_cohort_learned.sh || { log "FATAL: cohort learned eval failed"; exit 1; }
log ">>> Phase 2/2 LEARNED EVAL done"

lp=$(grep -c ' PASS' "$PROJECT/tb/runs/exp1_cohort_retrain/cohort_learned/results.txt" 2>/dev/null)
bp=$(grep -c ' PASS' "$PROJECT/tb/runs/exp1_cohort_pass3/cohort_base/results.txt" 2>/dev/null)
log "=== EXP1 COHORT CHAIN DONE === LEARNED ${lp:-0}/9 vs BASE ${bp:-0}/9 (1-shot: base 0/9, learned 1/9) — review for transfer signal"

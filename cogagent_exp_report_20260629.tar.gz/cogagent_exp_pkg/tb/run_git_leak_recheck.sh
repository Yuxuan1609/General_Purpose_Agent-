#!/bin/bash
# run_git_leak_recheck.sh — re-run the git eval's TIMED-OUT held-out case
# (git-leak-recovery) with the git LEARNED snapshot + an EXTENDED per-case cap so
# pass@3 actually completes → clean FAIL/PASS instead of ERR.
#   - eval @ 2400s cap → ERR (3 thorough learned attempts didn't fit)
#   - baseline (no learning) = clean FAIL @ 22min
# The eval showed the agent was DEADLINE-limited (stopped at turn 13/30 ~900s
# WITHOUT finishing) — the binding constraint was per-ATTEMPT working time, not the
# case cap. So give it real working time: per-attempt deadline 1800s (MULT=2) +
# per-case cap 3600s. (At 1800s/attempt only ~2 pass@3 attempts fit in 3600s.)
# Queued AFTER the cohort run (serial — one TB run at a time).
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
export TB_MAX_REPAIRS=2            # pass@3
export TB_DEADLINE_MULT=2         # ★ per-attempt deadline = native 900s × 2 = 1800s (real working time)
export EPOCH_CASE_TIMEOUT=3600    # ★ per-case cap = max(1800+1200, 3600) = 3600s

WAIT_PID="${WAIT_PID:-$(cat "$PROJECT/tb/runs/_bg/exp1_cohort.pid" 2>/dev/null)}"
SNAP="git_after_train"
CASE="git-leak-recovery"
EXP="$PROJECT/tb/runs/git_leak_recheck"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
log(){ echo "[git-leak-recheck $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }
_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=?"
import sqlite3
def c(db,t):
    try:return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception:return "?"
print("l1=%s l2=%s l3=%s"%(c("data/cognitive/l1.db","l1_rules"),c("data/cognitive/l2.db","l2_cards"),c("data/cognitive/l3.db","l3_skills")))
PY
}
_clean_all(){
  local ids; ids=$(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null)
  [ -n "$ids" ] && timeout 40 docker rm -f $ids >/dev/null 2>&1
  timeout 30 docker network prune -f >/dev/null 2>&1
  return 0
}

# wait for the cohort to finish (serial)
if [ -n "$WAIT_PID" ]; then
  log "waiting for cohort (PID=$WAIT_PID) to finish ..."
  while kill -0 "$WAIT_PID" 2>/dev/null; do sleep 120; done
  log "cohort finished; settling 20s ..."; sleep 20
fi

# reaper: rm container older than 4800s (>3600 cap, so cap fires first; backstop only)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 4800 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill "$REAPER" 2>/dev/null' EXIT

_clean_all
bash tb/exp_state.sh restore "$SNAP" >/dev/null 2>&1 && log "restored $SNAP ($(_counts)) — git-leak RECHECK WITH learning, deadline=1800s cap=3600s" || { log "FATAL restore $SNAP"; exit 1; }
log "=== GIT-LEAK RECHECK (git_after_train, bench/pass@3, deadline=1800s cap=3600s) — vs baseline FAIL / eval ERR ==="
EXP_DIR="$EXP" bash tb/run_epoch.sh bench git_leak_recheck "$CASE"
log "=== RECHECK DONE ==="
cat "$EXP/git_leak_recheck/results.txt" 2>/dev/null | sed 's/^/  结果: /' | tee -a "$SUM"
kill "$REAPER" 2>/dev/null

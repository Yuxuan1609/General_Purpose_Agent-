#!/bin/bash
# run_exp1_cohort_pass3.sh — auto-queued AFTER the git experiment: re-evaluate the
# 9 Exp1 cohort tasks at pass@3 (the 1-shot eval was too harsh: baseline 0/9, learned 1/9).
#   1) wait for the git chain (PID) to finish (serial — only one TB run at a time)
#   2) BASE pass@3    : restore exp1_seed      (NO learning)            → floor   (vs 1-shot 0/9)
#   3) LEARNED pass@3 : restore exp1_after_r3  (l1=7 l2=10, NO retrain) → transfer(vs 1-shot 1/9)
# Both: TB_PHASE=bench, TB_MAX_REPAIRS=2 (=pass@3), 1.0x deadline, serial, reaper + network prune.
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
export TB_MAX_REPAIRS=2          # pass@3 (initial + 2 repair retries)
unset  TB_DEADLINE_MULT          # eval uses 1.0x (match baseline)

GIT_PID="${GIT_PID:-$(cat "$PROJECT/tb/runs/_bg/git_chain.pid" 2>/dev/null)}"
COHORT="conda-env-conflict-resolution overfull-hbox mailman broken-networking polyglot-c-py write-compressor nginx-request-logging circuit-fibsqrt regex-chess"
EXP="$PROJECT/tb/runs/exp1_cohort_pass3"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
log(){ echo "[exp1-cohort $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }
_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=?"
import sqlite3
def c(db,t):
    try:return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception:return "?"
print("l1=%s l2=%s l3=%s"%(c("data/cognitive/l1.db","l1_rules"),c("data/cognitive/l2.db","l2_cards"),c("data/cognitive/l3.db","l3_skills")))
PY
}
_clean_all(){
  local ids; ids=$(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null)
  [ -n "$ids" ] && timeout 40 docker rm -f $ids >/dev/null 2>&1
  timeout 30 docker network prune -f >/dev/null 2>&1
  return 0
}

# 1) WAIT for the git experiment to finish (numeric PID — no pgrep self-match)
if [ -z "$GIT_PID" ]; then
  log "WARN: no git chain PID found — proceeding immediately"
else
  log "waiting for git experiment (PID=$GIT_PID) to finish ..."
  while kill -0 "$GIT_PID" 2>/dev/null; do sleep 120; done
  log "git experiment finished; settling 20s ..."
  sleep 20
fi

# reaper: rm container running >90min (started only now, so it never touches the git run)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 5400 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill "$REAPER" 2>/dev/null' EXIT

# 2) BASE pass@3 (no learning)
_clean_all
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1 && log "restored exp1_seed ($(_counts)) — BASE pass@3 NO learning" || { log "FATAL restore exp1_seed"; exit 1; }
log "=== EXP1 COHORT BASE pass@3 (9 tasks, bench/pass@3, NO learning) — vs 1-shot baseline 0/9 ==="
EXP_DIR="$EXP" bash tb/run_epoch.sh bench cohort_base "$COHORT"
bp=$(grep -c ' PASS' "$EXP/cohort_base/results.txt" 2>/dev/null)
log "BASE done: PASS ${bp:-0}/9"

# 3) LEARNED pass@3 (restore trained snapshot, NO retrain)
_clean_all
bash tb/exp_state.sh restore exp1_after_r3 >/dev/null 2>&1 && log "restored exp1_after_r3 ($(_counts)) — LEARNED pass@3 WITH learning" || { log "FATAL restore exp1_after_r3"; exit 1; }
log "=== EXP1 COHORT LEARNED pass@3 (9 tasks, bench/pass@3, WITH learning) — vs 1-shot eval 1/9 ==="
EXP_DIR="$EXP" bash tb/run_epoch.sh bench cohort_learned "$COHORT"
lp=$(grep -c ' PASS' "$EXP/cohort_learned/results.txt" 2>/dev/null)
log "LEARNED done: PASS ${lp:-0}/9"

log "=== EXP1 COHORT pass@3 DONE === BASE ${bp:-0}/9 | LEARNED ${lp:-0}/9  (1-shot was: base 0/9, learned 1/9)"
echo "  -- BASE --"   | tee -a "$SUM"; cat "$EXP/cohort_base/results.txt"    2>/dev/null | sed 's/^/    /' | tee -a "$SUM"
echo "  -- LEARNED --"| tee -a "$SUM"; cat "$EXP/cohort_learned/results.txt" 2>/dev/null | sed 's/^/    /' | tee -a "$SUM"
kill "$REAPER" 2>/dev/null

#!/bin/bash
# run_exp1_round.sh — Exp1 ONE round on the 7 cases:
#   TRAIN epoch (learning accumulates) → snapshot → TEST epoch (pure eval).
# Compares against the known seed baseline (these 7 all FAIL in test mode at seed).
# Assumes data/ is already at the desired starting state (e.g. seed restored).
#
# Includes a background container-reaper that removes any task container running
# > 45 min (recovers the rare docker-exec D-state wedge so the run never stalls).
#
# Usage: bash tb/run_exp1_round.sh
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
export EXP_DIR="$PROJECT/tb/runs/exp1"; mkdir -p "$EXP_DIR"
SUM="$EXP_DIR/summary.txt"
CASES="conda-env-conflict-resolution overfull-hbox modernize-fortran-build mailman vul-flink polyglot-c-py regex-chess"

# --- background reaper: recover docker-exec-wedged containers (>45min) ---
( while true; do
    sleep 60
    for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do
      st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null)
      [ -n "$st" ] || continue
      age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null || date +%s) ))
      if [ "$age" -gt 2700 ]; then
        echo "[reaper $(date +%H:%M:%S)] removing over-age container $c (${age}s)" >> "$SUM"
        timeout 30 docker rm -f "$c" >/dev/null 2>&1
      fi
    done
  done ) & REAPER=$!
trap 'kill $REAPER 2>/dev/null' EXIT

echo "############ Exp1 ONE-ROUND start $(date) ############" >> "$SUM"
echo "[start state: l2_cards=$($PY -c "import sqlite3;print(sqlite3.connect('data/cognitive/l2.db').execute('select count(*) from l2_cards').fetchone()[0])" 2>/dev/null)]" >> "$SUM"

# 1) TRAIN epoch — learning accumulates across the 7 cases
bash tb/run_epoch.sh train e1_train "$CASES"

# 2) snapshot learned state + show learning track
bash tb/exp_state.sh fork exp1_after_e1_train 2>&1 | head -1 >> "$SUM"
echo "  -- learning track after train --" >> "$SUM"
"$PY" -m core.learning_track >> "$SUM" 2>/dev/null
echo "  state: l2_cards=$($PY -c "import sqlite3;print(sqlite3.connect('data/cognitive/l2.db').execute('select count(*) from l2_cards').fetchone()[0])" 2>/dev/null) l3_skills=$(find data/layers/skills -name SKILL.md 2>/dev/null|wc -l)" >> "$SUM"

# 3) TEST epoch — pure test mode (no learning, no repair) on the SAME 7 cases
bash tb/run_epoch.sh test e1_test "$CASES"

# 4) brief comparison: train-epoch result vs test-epoch result per case
echo "" >> "$SUM"
echo "===== Exp1 one-round result (per case) =====" >> "$SUM"
"$PY" - "$EXP_DIR" <<'PYEOF' >> "$SUM" 2>/dev/null
import sys, os
base = sys.argv[1]
def load(lbl):
    p = os.path.join(base, lbl, "results.txt"); d = {}
    if os.path.exists(p):
        for ln in open(p):
            a = ln.split()
            if a: d[a[0]] = a[1] if len(a) > 1 else "?"
    return d
tr, te = load("e1_train"), load("e1_test")
cases = list(tr.keys()) or list(te.keys())
print("%-32s %-10s %-10s" % ("case", "train", "test(eval)"))
for c in cases:
    print("%-32s %-10s %-10s" % (c, tr.get(c, "-"), te.get(c, "-")))
print("-" * 54)
print("%-32s %-10s %-10s" % (
    "PASS",
    f"{sum(1 for c in cases if tr.get(c)=='PASS')}/{len(cases)}",
    f"{sum(1 for c in cases if te.get(c)=='PASS')}/{len(cases)}"))
PYEOF
echo "############ Exp1 ONE-ROUND DONE $(date) ############" >> "$SUM"

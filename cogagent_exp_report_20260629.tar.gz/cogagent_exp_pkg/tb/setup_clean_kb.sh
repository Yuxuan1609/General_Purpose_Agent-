#!/bin/bash
# Fork clean KB state for training experiments.
# Saves current data/ to a backup and creates clean state with only L0.5 seed content.
#
# Usage:
#   bash tb/setup_clean_kb.sh        # save current + create clean
#   bash tb/setup_clean_kb.sh restore  # restore from last backup

set -e
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"
DATA="$PROJECT/data"
BACKUP_BASE="$PROJECT/data_backup"

if [ "$1" = "restore" ]; then
    LATEST=$(ls -dt "$BACKUP_BASE"/*/ 2>/dev/null | head -1)
    if [ -z "$LATEST" ]; then
        echo "No backup found under $BACKUP_BASE"
        exit 1
    fi
    echo "Restoring from $LATEST"
    rm -rf "$DATA"
    cp -r "$LATEST" "$DATA"
    echo "Restored."
    exit 0
fi

# === Backup current state ===
TS=$(date +%Y%m%d_%H%M%S)
BACKUP="${BACKUP_BASE}/backup_${TS}_main"
mkdir -p "$(dirname "$BACKUP")"
echo "Backing up $DATA → $BACKUP"
cp -r "$DATA" "$BACKUP"

# === Create clean KB state ===
echo "Creating clean KB state..."

# 1. Clear KB index
rm -rf "$DATA/knowledge"
mkdir -p "$DATA/knowledge"

# 2. Clear learning
rm -rf "$DATA/learning/pending"
mkdir -p "$DATA/learning/pending"
echo '{"version":1}' > "$DATA/learning/learning_stats.json"

# 3. Clear L2 knowledge cards
rm -rf "$DATA/layers/knowledge"
mkdir -p "$DATA/layers/knowledge"
echo '{"version":1,"cards":[],"version_history":[]}' > "$DATA/layers/knowledge/l2_index.json"

# 4. Clear L3 skills
rm -rf "$DATA/layers/skills"
mkdir -p "$DATA/layers/skills"

# 5. Reset domain registry (keep minimal domains)
python3 << 'PYEOF'
import json, os
PROJECT = os.environ.get("PROJECT", ".")
data_dir = os.path.join(PROJECT, "data")
registry_path = os.path.join(data_dir, "layers", "domain_registry.json")
with open(registry_path, "w") as f:
    json.dump({"version": 1, "domains": []}, f, indent=2)
print("  domain_registry: reset to empty")
PYEOF

# 6. Reset L1 rules to seed backup (L0.5 content only)
SEED="$DATA/layers/l1_rules_seed_backup.json"
TARGET="$DATA/layers/l1_rules.json"
if [ -f "$SEED" ]; then
    cp "$SEED" "$TARGET"
    echo "  l1_rules: reset from seed backup ($(python3 -c "import json; print(len(json.load(open('$SEED'))))" ) rules)"
else
    echo "  WARNING: seed backup not found at $SEED"
fi

echo ""
echo "Clean KB state ready at $DATA"
echo "Backup saved to $BACKUP"
echo ""
echo "To restore: bash tb/setup_clean_kb.sh restore"

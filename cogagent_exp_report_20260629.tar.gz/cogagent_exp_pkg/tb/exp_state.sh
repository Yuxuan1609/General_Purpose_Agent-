#!/bin/bash
# Experiment learning-state snapshot tool.
#
# Snapshots the FULL learning state so experiments can be isolated/reproduced:
#   - L1 / L2 / L3 / domain  → data/cognitive/{l1,l2,l3,domain}.db (live SQLite)
#   - KB (vector index)      → data/knowledge/
#   - learning records       → data/learning/ (pending, archive, track)
#   - layer JSON + skills     → data/layers/
# A full data/ snapshot captures ALL of them (KB *and* L1/L2/L3 *and* domain).
#
# NOTE: setup_clean_kb.sh only resets the stale JSON indexes, NOT the live
# data/cognitive/*.db — so it is NOT sufficient for experiment isolation. Use
# this tool instead.
#
# Usage:
#   bash tb/exp_state.sh fork <name>      # snapshot current data/ → data_snapshots/<name>
#   bash tb/exp_state.sh restore <name>   # restore data/ from a snapshot
#   bash tb/exp_state.sh list
set -e
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"
DATA="$PROJECT/data"
SNAP="$PROJECT/data_snapshots"

cmd="${1:-}"; name="${2:-}"
case "$cmd" in
  fork)
    [ -z "$name" ] && { echo "usage: fork <name>"; exit 1; }
    mkdir -p "$SNAP"
    rm -rf "$SNAP/$name"
    cp -r "$DATA" "$SNAP/$name"
    echo "forked data/ → $SNAP/$name"
    echo "  L1/L2/L3/domain (cognitive/*.db): $(ls "$SNAP/$name"/cognitive/*.db 2>/dev/null | wc -l) dbs"
    echo "  KB (knowledge/):                  $(du -sh "$SNAP/$name"/knowledge 2>/dev/null | cut -f1)"
    echo "  learning/ pending+archive:        $(find "$SNAP/$name"/learning -name '*.json' 2>/dev/null | wc -l) files"
    ;;
  restore)
    [ -z "$name" ] && { echo "usage: restore <name>"; exit 1; }
    [ -d "$SNAP/$name" ] || { echo "no snapshot named '$name' under $SNAP"; exit 1; }
    rm -rf "$DATA"
    cp -r "$SNAP/$name" "$DATA"
    # Clear any stale un-consolidated pending records baked into the snapshot:
    # they are a transient consolidation queue, and if left they get auto-
    # consolidated mid/end of a later run (pending>=5 trigger) — writing L2 cards
    # into a supposedly read-only bench/eval and polluting state. A restore should
    # always start with an empty queue.
    pend=$(ls "$DATA"/learning/pending/*.json 2>/dev/null | wc -l)
    rm -f "$DATA"/learning/pending/*.json 2>/dev/null || true
    echo "restored data/ from snapshot '$name' (cleared $pend stale pending record(s))"
    ;;
  list)
    ls -1dt "$SNAP"/*/ 2>/dev/null | sed "s#$SNAP/##;s#/\$##" || echo "(no snapshots)"
    ;;
  *)
    echo "usage: $0 {fork|restore|list} [name]"; exit 1
    ;;
esac

#!/bin/bash
# run_git_chain.sh — Git transfer experiment, autonomous: TRAIN then EVAL.
#   1) run_git_train.sh : 3 rounds train on 3 PASS git tasks (learning ON)
#   2) run_git_eval.sh  : bench/pass@3 on 2 held-out git tasks WITH learning
# Serial, hands-off. Compare eval to clean git baseline 0/2.
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
mkdir -p "$PROJECT/tb/runs/_bg"
SUM="$PROJECT/tb/runs/git_chain.log"
log(){ echo "[git-chain $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }

log "=== GIT EXPERIMENT CHAIN START ==="
log ">>> Phase 1/2: TRAIN"
bash tb/run_git_train.sh || { log "FATAL: git train failed"; exit 1; }
log ">>> Phase 1/2 TRAIN done"

log ">>> Phase 2/2: EVAL (held-out, WITH learning)"
bash tb/run_git_eval.sh || { log "FATAL: git eval failed"; exit 1; }
log ">>> Phase 2/2 EVAL done"

gp=$(grep -c ' PASS' "$PROJECT/tb/runs/git_eval/git_eval/results.txt" 2>/dev/null)
log "=== GIT EXPERIMENT CHAIN DONE === eval PASS ${gp:-0}/2 vs baseline 0/2 — review for transfer signal"

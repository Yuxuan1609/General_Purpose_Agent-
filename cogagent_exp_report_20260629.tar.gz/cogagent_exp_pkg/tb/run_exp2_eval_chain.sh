#!/bin/bash
# run_exp2_eval_chain.sh — post-Phase-1 chain (auto, serial):
#   wait for Phase-1 build train (phase1 PID) to finish, then:
#   1) BUILD EVAL : restore exp2_after_train (learned) → bench/pass@3 on 3 held-out build tasks
#   2) GIT BASELINE: restore exp1_seed (clean)        → bench/pass@3 on 5 git tasks
# Both: TB_PHASE=bench (learning OFF, feedback ON), TB_MAX_REPAIRS=2 (=pass@3), 1.0x deadline.
# Step 3 (git train+eval experiment) is DEFERRED to a manual decision after build eval.
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
export PATH="$PROJECT/.venv/bin:$HOME/.local/bin:$PATH"
export PYTHONPATH="$PROJECT:$PYTHONPATH"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
export TB_MAX_REPAIRS=2          # pass@3 (initial + 2 repair retries)
unset  TB_DEADLINE_MULT          # eval/baseline use 1.0x — match the build pass@3 baseline

PHASE1_PID="${PHASE1_PID:-1285943}"
EXP="$PROJECT/tb/runs/exp2_eval"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
BUILD_TEST="build-tcc-qemu build-cython-ext sudo-llvm-ir"
GIT_CASES="merge-diff-arc-agi-task git-leak-recovery git-multibranch sanitize-git-repo configure-git-webserver"
log(){ echo "[exp2-eval $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }
_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=?"
import sqlite3
def c(db,t):
    try:return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except:return "?"
print("l1=%s l2=%s l3=%s"%(c("data/cognitive/l1.db","l1_rules"),c("data/cognitive/l2.db","l2_cards"),c("data/cognitive/l3.db","l3_skills")))
PY
}
_clean(){ local ids; ids=$(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null); [ -n "$ids" ] && timeout 40 docker rm -f $ids >/dev/null 2>&1; return 0; }

# 1) wait for Phase-1 train (numeric PID — no pgrep self-match deadlock)
log "waiting for Phase-1 (PID=$PHASE1_PID) to finish ..."
while kill -0 "$PHASE1_PID" 2>/dev/null; do sleep 30; done
log "Phase-1 finished; settling 15s ..."; sleep 15
[ -d "data_snapshots/exp2_after_train" ] || { log "FATAL: data_snapshots/exp2_after_train missing — abort"; exit 1; }

# reaper insurance (build eval has heavy tasks; kill >90min containers)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 5400 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill $REAPER 2>/dev/null' EXIT

# 2) BUILD EVAL — 3 held-out build tasks, WITH learning
_clean
bash tb/exp_state.sh restore exp2_after_train >/dev/null 2>&1 && log "restored exp2_after_train ($(_counts)) — build eval WITH learning" || { log "FATAL restore exp2_after_train"; exit 1; }
log "=== BUILD EVAL (held-out 3, bench/pass@3, WITH learning) — compare to build pass@3 baseline 0/3 ==="
EXP_DIR="$EXP" bash tb/run_epoch.sh bench build_eval "$BUILD_TEST"
bp=$(grep -c ' PASS' "$EXP/build_eval/results.txt" 2>/dev/null)
log "BUILD EVAL done: PASS ${bp:-0}/3  (baseline 0/3)"

# 3) GIT pass@3 BASELINE — 5 git tasks, clean (no learning)
_clean
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1 && log "restored exp1_seed (clean) — git baseline NO learning" || { log "FATAL restore exp1_seed"; exit 1; }
log "=== GIT pass@3 BASELINE (5 tasks, bench/pass@3, NO learning) ==="
EXP_DIR="$EXP" bash tb/run_epoch.sh bench git_baseline "$GIT_CASES"
gp=$(grep -c ' PASS' "$EXP/git_baseline/results.txt" 2>/dev/null)
log "GIT BASELINE done: PASS ${gp:-0}/5"

_clean
log "=== CHAIN DONE === build_eval=${bp:-0}/3 | git_baseline=${gp:-0}/5 — review, then decide git experiment (step 4)"

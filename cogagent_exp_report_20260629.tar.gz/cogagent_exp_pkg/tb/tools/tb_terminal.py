"""TB terminal tool — executes commands in Docker container via TmuxSession."""
from __future__ import annotations
import json
import logging
import threading
import time

logger = logging.getLogger(__name__)
from tb.session_holder import tmux_session_lock as _lock  # shared w/ read_file+grep (same tmux session)
# Set once per task process (process isolation per task) — disables pagers on
# the agent's first terminal command so git/man/etc never open a blocking pager.
_pager_setup_done = False


def register_tb_terminal_tool(registry):
    def handler(args=None, timeout=300):
        command = (args or {}).get("command", "")
        if not command:
            return json.dumps({"error": "No command provided"})

        # Guard: the agent sometimes mis-reads a slow command (e.g. a long build)
        # as a "hung tmux" and tries to pkill/kill tmux or bash to "recover" — but
        # that destroys the very tmux channel used to drive the container, after
        # which ALL commands fail and the agent spirals into more kill attempts.
        # Refuse such commands and tell the agent what to do instead.
        import re
        if re.search(r'\b(pkill|killall|kill)\b[^\n]*\b(tmux|bash)\b', command, re.I) \
                or re.search(r'tmux\s+kill-(server|session)', command, re.I):
            return json.dumps({"error": (
                "已拒绝：不要 kill/pkill tmux 或 bash —— 这会摧毁你与容器通信的命令通道，"
                "之后所有命令都会失效。命令超时通常不是 tmux 挂了，而是命令本身慢（如编译/下载）。"
                "正确做法：长命令用 sync=false 后台执行，或把输出重定向到文件再分步查看；切勿试图重置 tmux。"
            )})

        with _lock:
            from tb.session_holder import get
            session = get()

            # One-time pager disable, done on the agent's FIRST terminal command
            # (when the container shell is guaranteed to be at a prompt — doing it
            # at session-start races with shell startup and silently no-ops, after
            # which `git show/log/diff` opens /usr/bin/pager and wedges the tmux
            # channel at `(END)` until the wall-clock cap). git config --global
            # writes ~/.gitconfig (file-level, persists for the whole container,
            # survives across pass@3 repair rounds); env vars cover man/systemctl.
            global _pager_setup_done
            if not _pager_setup_done:
                _pager_setup_done = True
                try:
                    session.send_keys(
                        ["git config --global core.pager cat; "
                         "export PAGER=cat GIT_PAGER=cat SYSTEMD_PAGER=cat LESS=FRX",
                         "Enter"],
                        block=True, max_timeout_sec=15,
                    )
                    session.get_incremental_output()
                except Exception:
                    logger.warning("pager-disable setup failed", exc_info=True)

            # Drain incremental state before command
            session.get_incremental_output()

            # Split multi-line commands (heredoc, etc.) into individual key
            # arguments. Docker exec API corrupts args containing literal \n,
            # so each line becomes a separate tmux send-keys argument with
            # "Enter" between them.
            #
            # TB harness _prevent_execution strips trailing "Enter" keys, then
            # appends "; tmux wait -S done" as the next key arg. tmux types
            # consecutive args without a line break, so the completion marker
            # would land on the same line as the heredoc terminator (e.g.
            # "EOF; tmux wait -S done"), which bash doesn't recognize as the
            # heredoc delimiter. Appending "true" forces the completion marker
            # onto a separate line after the heredoc closes.
            lines = command.split('\n')
            keys = []
            for line in lines:
                keys.append(line)
                keys.append("Enter")
            if len(lines) > 1:
                keys.append("true")
                keys.append("Enter")
            # Floor the per-command timeout at 300s (the intended config value;
            # the wired-in value was a too-short 30s that made long build/compile
            # commands spuriously "time out", which the agent then mis-handled).
            # This is a MAX, not a fixed wait — fast commands still return as soon
            # as they finish; only genuinely long commands get the headroom.
            timeout_f = max(float(timeout), 300.0)
            # send_keys(block=True) drives the container via multiple docker-exec
            # round-trips (type keys, then `timeout Ns tmux wait done`). Under
            # parallel load the docker-exec API call itself can hang indefinitely
            # — the in-container `timeout` does NOT bound a stuck exec call, and
            # there is no other python-side timeout. So run send_keys under a
            # watchdog thread: if it hasn't returned within the command timeout
            # plus a margin, abandon it and return an error instead of blocking
            # the agent forever (which previously stuck the agent in round 0 until
            # its whole agent-timeout budget elapsed → AGENT_TIMEOUT failure).
            done_evt = threading.Event()
            box: dict = {}

            def _send():
                try:
                    session.send_keys(keys, block=True, max_timeout_sec=timeout_f)
                except BaseException as e:  # noqa: BLE001
                    box["err"] = e
                finally:
                    done_evt.set()

            threading.Thread(target=_send, daemon=True).start()
            if not done_evt.wait(timeout_f + 30.0):
                logger.error(
                    "terminal watchdog: send_keys hung >%.0fs, abandoning (cmd=%.80r)",
                    timeout_f + 30.0, command,
                )
                return json.dumps({
                    "error": (
                        f"Command hung (watchdog {timeout_f + 30:.0f}s) — "
                        "terminal/docker-exec did not return"
                    )
                })
            err = box.get("err")
            if isinstance(err, TimeoutError):
                return json.dumps({"error": f"Command timed out ({timeout}s)"})
            if err is not None:
                # Never surface an empty error: a bare str() can be "" for some
                # docker/exec exceptions, which is useless to the agent.
                return json.dumps({"error": str(err) or repr(err) or type(err).__name__})

            time.sleep(0.3)
            output = session.get_incremental_output()

        return json.dumps({
            "command": command,
            "output": output,
        }, ensure_ascii=False)

    registry.register("terminal", {
        "type": "function",
        "function": {
            "name": "terminal",
            "description": (
                "Execute a shell command in the TB Docker container and capture "
                "the terminal output. Commands run inside the task container via tmux."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "Shell command to execute in the container",
                    },
                    "sync": {
                        "type": "boolean",
                        "description": "true=blocking(default)",
                    },
                },
                "required": ["command"],
            },
        },
    }, handler, toolset="core", override=True)

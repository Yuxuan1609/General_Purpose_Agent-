"""TB write_file tool — reliably write file content into the Docker container.

The agent otherwise has no safe way to create/overwrite files: doing it via the
``terminal`` tool means typing a multi-line heredoc (``cat > f << EOF ... EOF``)
through tmux send-keys, which is fragile — if any line mis-types or the EOF
delimiter doesn't land exactly on its own line, the shell stays in heredoc-input
mode forever and the blocking completion marker (``; tmux wait -S done``) gets
swallowed as heredoc body → the command never completes → hang (bounded only by
the watchdog). write_file sidesteps all of that by base64-encoding the content
and writing it with single-line, special-char-free commands
(``printf %s '<b64>' | base64 -d > path``), chunked for large files.
"""
from __future__ import annotations
import base64
import json
import logging
import os
import threading
import time

logger = logging.getLogger(__name__)
_lock = threading.Lock()

# base64 chars per single-line append — keeps each command small/safe for tmux.
_CHUNK = 2000


def _sq(s: str) -> str:
    """POSIX single-quote a string for safe inclusion in a shell command."""
    return "'" + s.replace("'", "'\\''") + "'"


def _send_line(session, cmd: str, timeout_f: float):
    """Send ONE single-line command via tmux (blocking) under a watchdog.

    Returns None on success, else an error string. Single-line means the TB
    completion marker executes right after the command (never swallowed), so —
    unlike a heredoc — this completes reliably. The watchdog mirrors tb_terminal
    so a stuck docker-exec can't hang the agent forever.
    """
    keys = [cmd, "Enter"]
    done_evt = threading.Event()
    box: dict = {}

    def _send():
        try:
            session.send_keys(keys, block=True, max_timeout_sec=timeout_f)
        except BaseException as e:  # noqa: BLE001
            box["err"] = e
        finally:
            done_evt.set()

    threading.Thread(target=_send, daemon=True).start()
    if not done_evt.wait(timeout_f + 30.0):
        logger.error("write_file watchdog: send_keys hung >%.0fs (cmd=%.80r)",
                     timeout_f + 30.0, cmd)
        return f"command hung (watchdog {timeout_f + 30:.0f}s)"
    err = box.get("err")
    if err is not None:
        return str(err) or repr(err) or type(err).__name__
    return None


def register_tb_write_file(registry):
    def handler(args=None, timeout=300):
        a = args or {}
        path = a.get("path", "")
        content = a.get("content", "")
        if not path:
            return json.dumps({"error": "No path provided"})
        if not isinstance(content, str):
            content = str(content)

        b64 = base64.b64encode(content.encode("utf-8")).decode("ascii")
        tmp = path + ".b64tmp"
        cmds: list[str] = []
        d = os.path.dirname(path)
        if d:
            cmds.append(f"mkdir -p {_sq(d)}")
        chunks = [b64[i:i + _CHUNK] for i in range(0, len(b64), _CHUNK)] or [""]
        for i, ch in enumerate(chunks):
            op = ">" if i == 0 else ">>"
            cmds.append(f"printf %s {_sq(ch)} {op} {_sq(tmp)}")
        cmds.append(f"base64 -d {_sq(tmp)} > {_sq(path)} && rm -f {_sq(tmp)}")

        timeout_f = float(timeout)
        with _lock:
            from tb.session_holder import get
            session = get()
            session.get_incremental_output()
            for cmd in cmds:
                err = _send_line(session, cmd, timeout_f)
                if err is not None:
                    return json.dumps({"error": f"write_file failed: {err}"})
            time.sleep(0.2)
            out = session.get_incremental_output() or ""

        return json.dumps({
            "status": "ok",
            "path": path,
            "bytes": len(content.encode("utf-8")),
            "output": out[-400:],
        }, ensure_ascii=False)

    registry.register("write_file", {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": (
                "Create or overwrite a file in the container with exact content. "
                "Use this for ALL file creation/overwriting (single OR multi-line). "
                "Do NOT write files via terminal heredocs (cat << EOF) — those are "
                "unreliable. Parent directories are created automatically."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Absolute file path in the container",
                    },
                    "content": {
                        "type": "string",
                        "description": "Full file content to write",
                    },
                    "sync": {
                        "type": "boolean",
                        "description": "true=blocking(default)",
                    },
                },
                "required": ["path", "content"],
            },
        },
    }, handler, toolset="core", override=True)

#!/bin/bash
# run_git_eval.sh — Git transfer experiment, EVAL phase: restore the git-trained
# state (git_after_train) and run bench/pass@3 on the 2 HELD-OUT git tasks WITH
# learning (read-only), comparing to the clean baseline 0/2 (both FAIL in the
# git pass@3 baseline). This is the transfer measurement.
#
# Usage:  bash tb/run_git_eval.sh
# Env:    GIT_EVAL_SNAP (default git_after_train), TB_MAX_REPAIRS (default 2)
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
export TB_MAX_REPAIRS="${TB_MAX_REPAIRS:-2}"   # pass@3
unset  TB_DEADLINE_MULT                         # eval uses 1.0x (match baseline)

SNAP="${GIT_EVAL_SNAP:-git_after_train}"
HELD_OUT="git-leak-recovery configure-git-webserver"
EXP="$PROJECT/tb/runs/git_eval"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
log(){ echo "[git-eval $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }
_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=?"
import sqlite3
def c(db,t):
    try:return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception:return "?"
print("l1=%s l2=%s l3=%s"%(c("data/cognitive/l1.db","l1_rules"),c("data/cognitive/l2.db","l2_cards"),c("data/cognitive/l3.db","l3_skills")))
PY
}
_clean_all(){
  local ids; ids=$(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null)
  [ -n "$ids" ] && timeout 40 docker rm -f $ids >/dev/null 2>&1
  timeout 30 docker network prune -f >/dev/null 2>&1
  return 0
}

# reaper: rm container running >90min
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 5400 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill "$REAPER" 2>/dev/null' EXIT

_clean_all
bash tb/exp_state.sh restore "$SNAP" >/dev/null 2>&1 && log "restored $SNAP ($(_counts)) — git EVAL WITH learning" || { log "FATAL restore $SNAP"; exit 1; }
log "=== GIT EVAL (held-out 2, bench/pass@3, WITH learning) — compare to git baseline 0/2 ==="
log "held-out: $HELD_OUT"
EXP_DIR="$EXP" bash tb/run_epoch.sh bench git_eval "$HELD_OUT"
gp=$(grep -c ' PASS' "$EXP/git_eval/results.txt" 2>/dev/null)
log "=== GIT EVAL DONE: PASS ${gp:-0}/2 (baseline was 0/2) ==="
cat "$EXP/git_eval/results.txt" 2>/dev/null | sed 's/^/  /' | tee -a "$SUM"
kill "$REAPER" 2>/dev/null

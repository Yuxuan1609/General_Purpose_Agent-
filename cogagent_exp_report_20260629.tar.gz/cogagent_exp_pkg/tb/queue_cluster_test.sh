#!/bin/bash
# queue_cluster_test.sh — wait for the running baseline-14 to finish, then run a
# TEST-mode (1-shot, no learning) pass over the build-from-source + git clusters
# to find which tasks the agent CANNOT solve 1-shot → those become the Exp2
# (generalization) train/test cohort (need >=2-3 fails per cluster).
#
# Serial via run_epoch.sh test (per-case internal deadline + CAP). Does NOT run
# concurrently with baseline-14 (waits for it first) to avoid docker-exec flake.
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
mkdir -p "$PROJECT/tb/runs/exp_cluster" "$PROJECT/tb/runs/_bg"
SUM="$PROJECT/tb/runs/exp_cluster/summary.txt"

CASES="build-cython-ext build-pmars build-stp gcc-compiler-optimization sudo-llvm-ir build-tcc-qemu build-initramfs-qemu compile-compcert build-linux-kernel-qemu merge-diff-arc-agi-task git-leak-recovery git-multibranch sanitize-git-repo configure-git-webserver"

# 1) wait for baseline-14
B14=$(cat tb/runs/_bg/baseline14.pid 2>/dev/null)
echo "[queue $(date '+%H:%M:%S')] waiting for baseline-14 (pid=$B14)..." >> "$SUM"
while [ -n "$B14" ] && kill -0 "$B14" 2>/dev/null; do sleep 60; done
echo "[queue $(date '+%H:%M:%S')] baseline-14 finished; starting cluster test" >> "$SUM"

# kill baseline-14's reaper + clean leftover containers
kill -KILL "$(cat tb/runs/_bg/baseline14-reaper.pid 2>/dev/null)" 2>/dev/null
sleep 5
for c in $(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null); do timeout 40 docker rm -f "$c" >/dev/null 2>&1; done

# 2) clean seed (test mode writes no learning, but start clean/consistent)
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1

# 3) reaper for the cluster test (D-state insurance: rm >90min containers)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ] || continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null || date +%s) )); [ "$age" -gt 5400 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill $REAPER 2>/dev/null' EXIT

# 4) run the cluster test (test mode)
EXP_DIR="$PROJECT/tb/runs/exp_cluster" bash tb/run_epoch.sh test cluster_build_git "$CASES"
echo "[queue $(date '+%H:%M:%S')] cluster test DONE" >> "$SUM"

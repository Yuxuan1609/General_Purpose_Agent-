#!/bin/bash
# run_exp1_full.sh — one-shot Exp1: N rounds of TRAIN (learning accumulates) then
# a final EVAL (test mode, on the learned state). Same-task improvement experiment.
#
# Iterative learning model:
#   restore seed ONCE  →  train r1 (record_learning → consolidate → L1/L2/L3)  →
#   train r2 (from r1 state) … → train rN  →  EVAL in test mode on the final state
#   (NO seed restore before eval, so the agent USES everything it learned).
#
# Per-round flow enforced here (matches the experiment requirement):
#   train: run_epoch records PASS/FAIL  +  agent record_learning (reflection)  +
#          DRAIN pending → consolidate into L1/L2/L3 (auto-trigger only fires at
#          >=5 pending, so we force-drain leftovers each round).
#   eval:  run_epoch records PASS/FAIL only (test mode: learning-write denied).
#
# Usage:   bash tb/run_exp1_full.sh ["<case1 case2 ...>"]
# Env:     EXP1_TAG    run dir tb/runs/$EXP1_TAG + snapshot prefix (default exp1)
#          EXP1_ROUNDS number of train rounds (default 3)
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a

TAG="${EXP1_TAG:-exp1}"
ROUNDS="${EXP1_ROUNDS:-3}"
CASES="${1:-conda-env-conflict-resolution overfull-hbox mailman broken-networking polyglot-c-py write-compressor nginx-request-logging circuit-fibsqrt regex-chess}"
NCASE=$(echo $CASES | wc -w)

EXP="$PROJECT/tb/runs/$TAG"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
log(){ echo "[$TAG $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }

# learning-state snapshot: L1 rules / L2 cards / L3 skills / pending / archive
_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=? pending=? archive=?"
import sqlite3,glob
def cnt(db,t):
    try: return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception: return "?"
print("l1=%s l2=%s l3=%s pending=%d archive=%d" % (
    cnt("data/cognitive/l1.db","l1_rules"),
    cnt("data/cognitive/l2.db","l2_cards"),
    cnt("data/cognitive/l3.db","l3_skills"),
    len(glob.glob("data/learning/pending/*.json")),
    len(glob.glob("data/archive/**/*.json",recursive=True))))
PY
}

# Force-consolidate leftover pending so learnings reach L1/L2/L3 before the next
# round / eval. The auto-trigger only fires at >=5 pending, so a round can leave
# <5 unconsolidated; consolidate_runner reads ALL pending in one foreground pass.
_drain_pending(){
  # 1) let any in-flight (agent-spawned) consolidation finish
  for i in $(seq 1 120); do pgrep -f core.consolidate_runner >/dev/null || break; sleep 5; done
  # 2) force-drain remaining pending (guard against no-progress loops)
  local guard=0
  while [ "$(ls data/learning/pending/*.json 2>/dev/null | wc -l)" -gt 0 ] && [ "$guard" -lt 4 ]; do
    guard=$((guard+1))
    local dom; dom=$("$PY" - 2>/dev/null <<'PY'
import glob,json,collections
d=collections.Counter()
for f in glob.glob("data/learning/pending/*.json"):
    try: d[json.load(open(f)).get("domain","interaction")]+=1
    except Exception: d["interaction"]+=1
print(d.most_common(1)[0][0] if d else "interaction")
PY
)
    log "  drain[$guard]: consolidating pending (domain=$dom) → L1/L2/L3 ..."
    "$PY" -m core.consolidate_runner --domain "$dom" >> "$EXP/consolidate.log" 2>&1
    for i in $(seq 1 120); do pgrep -f core.consolidate_runner >/dev/null || break; sleep 5; done
  done
}

log "START  rounds=$ROUNDS  cases=$NCASE"
log "cohort: $CASES"

# 0) clean seed ONCE — learning then accumulates across the N rounds
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1 && log "seed restored ($(_counts))" || { log "FATAL: seed restore failed"; exit 1; }

# reaper insurance: rm any container running >90min (D-state safety net)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 5400 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill $REAPER 2>/dev/null' EXIT

# 1) N rounds of TRAIN (accumulating; consolidated per-case + force-drained per-round)
for r in $(seq 1 "$ROUNDS"); do
  log "=== TRAIN round $r/$ROUNDS ===  (before: $(_counts))"
  EXP_DIR="$EXP" bash tb/run_epoch.sh train "r$r" "$CASES"
  log "  r$r training done; draining pending → L1/L2/L3 ..."
  _drain_pending
  bash tb/exp_state.sh fork "${TAG}_after_r$r" >/dev/null 2>&1
  rp=$(grep -c ' PASS' "$EXP/r$r/results.txt" 2>/dev/null)
  log "round $r DONE: train PASS $rp/$NCASE | learning: $(_counts) | snapshot=${TAG}_after_r$r"
done

# 2) final EVAL — test mode, on the learned state (NO seed restore)
log "=== EVAL (test mode, learned state) ===  (learning: $(_counts))"
EXP_DIR="$EXP" bash tb/run_epoch.sh test "eval" "$CASES"

# 3) summary vs baseline (every cohort case was FAIL at clean baseline → 0/$NCASE)
ep=$(grep -c ' PASS' "$EXP/eval/results.txt" 2>/dev/null)
log "=== RESULTS: eval PASS $ep/$NCASE  (clean baseline was 0/$NCASE) ==="
sed 's/^/    /' "$EXP/eval/results.txt" | tee -a "$SUM"
log "final learning state: $(_counts)"
log "DONE"

"""TB env helper — apply learning context to chain layers.

Uses existing AgentContext + set_context mechanism for dynamic tool filtering.
Train (enable=True): all tools available.
Bench/Test (enable=False): ALL learning-state-write tools denied so the run
  cannot mutate the learned state — no record_learning, no direct
  card/rule/skill creation, no domain mutation. Reading learned knowledge
  (kb_query / query_domain / l1_query) stays allowed.
"""
from __future__ import annotations

# Every tool that mutates the learned / knowledge / domain state. Denied in
# bench/test so a "no-learning" run cannot contaminate the learning store via a
# back door (e.g. the L2 agent calling create_l2_card directly during solving).
# query_domain / kb_query are READ-only and intentionally NOT denied.
#
# activate_secondary_tools is the MASTER gate: secondary (on-demand) tools are
# enabled at runtime via this primary tool and merged into the live tool list
# WITHOUT re-applying ctx.resolve — so a denied write tool (e.g. record_learning)
# could be re-activated through this back door. Denying activate_secondary_tools
# itself shuts that path for every secondary write tool. Not used by TB solving
# (terminal/read_file/etc. are base tools), so denying it is safe in bench/test.
_LEARNING_WRITE_TOOLS = {
    "activate_secondary_tools",
    "record_learning", "kb_add", "kb_fill_gap", "kb_delete", "kb_modify",
    "create_l1_rule", "modify_l1_rule", "deprecate_l1_rule",
    "create_l2_card", "modify_l2_card", "deprecate_l2_card",
    "create_l3_skill", "modify_l3_skill", "deprecate_l3_skill",
    "create_domain", "merge_domain", "deprecate_domain",
}


def apply_learning_context(chain, enable: bool) -> None:
    """Apply tool context to all chain layers.

    Args:
        chain: Root layer node of the cognitive chain.
        enable: If True, all tools available (train mode).
                If False, all learning-state-write tools denied (bench/test).
    """
    from core.agent_context import AgentContext

    ctx = None
    if not enable:
        ctx = AgentContext(denied_tools=set(_LEARNING_WRITE_TOOLS))

    node = chain
    while node is not None:
        agent = getattr(node, '_agent', None)
        if agent is not None:
            agent.set_context(ctx)
        node = getattr(node, '_downstream', None)

# Terminal-Bench 学习实验 — 标准化脚本 & 说明书

承接 `TB_EXPERIMENT_PLAN.md`。这里是**一键运行**实验的脚本和操作手册。

---

## 0. 三个标准化脚本

| 脚本 | 作用 | 用法 |
|------|------|------|
| `tb/exp_state.sh` | 全量学习状态快照/回滚（**KB + L1 + L2 + L3 + domain + learning**，即整个 `data/`） | `fork <name>` / `restore <name>` / `list` |
| `tb/run_epoch.sh` | building block：一组 case **跑一遍**（train 或 test 模式，串行） | `<train\|test> <label> "<cases>"` |
| `tb/run_exp1.sh` | **实验一 orchestrator**（一键）：seed→test_e0→[train→快照→test]×N→结果矩阵 | `[N_epochs]`（默认 3） |

> 活存储是 SQLite `data/cognitive/*.db`；`setup_clean_kb.sh` 不清它，**实验隔离一律用 `exp_state.sh`**。

---

## 1. 实验一：一键启动

```bash
cd /home/admin/cognitive-agent
# 前提：已有干净 seed 快照（出厂态）。若无：
#   bash tb/exp_state.sh restore <pristine_backup> && bash tb/exp_state.sh fork exp1_seed
# 后台跑 3 个 epoch：
nohup bash tb/run_exp1.sh 3 > tb/runs/_bg/exp1.log 2>&1 & disown
# 看进度：
tail -f tb/runs/exp1/summary.txt
```

### 协议（run_exp1.sh 自动执行）
1. `restore exp1_seed` → 回到出厂 seed（l2_cards=1、无学习）
2. **test epoch e0**：7 个 case 在**纯 test 模式**跑一遍 → 学习前基线通过率
3. for r in 1..N：
   - **train epoch**：7 个 case **train 模式**串行跑（perform_task + ≤3 轮 repair；record_learning→固化**累积**）；case 间等固化子进程跑完，知识传给下一个 case
   - `fork exp1_after_e{r}_train`（快照）
   - **test epoch**：7 个 case **纯 test 模式**跑一遍（无学习、无 repair）→ 带"已学知识"的通过率
4. 打印**结果矩阵**：每个 case 在 e0/e1/.../eN 的 test 通过情况

### 怎么读结果
- `tb/runs/exp1/summary.txt`：逐 epoch、逐 case 的 PASS/FAIL + 每轮学习 track（record_learning 调用数 / 固化状态）+ 末尾矩阵。
- **关键信号**：test 通过率是否随 epoch 上升（e0→e1→e2→e3）。上升 = 累积学习让这些 case 在纯测试下变得能过 → 概念验证成立（理想情况下框架有意义）。
- 快照 `data_snapshots/exp1_after_e{r}_train`：每轮训练后的完整学习态，可 `restore` 复现/对比。

---

## 2. 方法论要点（为什么这么设计）

- **seed 重置 + 快照隔离**：每个实验从已知 seed 出发、用 `exp_state.sh` 隔离，避免跨实验污染。
- **train 串行（并发=1）**：学习顺序可复现、干净归因；并避免 docker-exec 高并发 flake。
- **test epoch 纯净**：test 模式 `apply_learning_context` 禁掉 record_learning/kb_add/kb_fill_gap 且跳过 repair → 不学习、不改状态 → 是干净的能力评估（隔离了 repair loop 的助攻）。
- **case 间等固化**：record_learning→（≥5 条触发）独立子进程固化进 L1/L2/L3+KB；脚本等它跑完再进下一个 case，保证知识可用。
- **每 case wall-clock 上限**（`EPOCH_CASE_TIMEOUT`，默认 2400s）：防单个 case 卡死拖垮整轮。
- **容器清理**用 `name=1-of-1` 过滤（TB 容器名是 `<task>-1-of-1-<runid>`），docker 操作全 `timeout` 包裹。

---

## 3. 扩展到实验二/三（复用同样的积木）

- **实验二（timeout 修复与评估）**：把 6 个 round-0 超时 case 当作 cases，同样 train→test 跑；额外看 round-0 turn 数 / 是否进 round 1 / 重试次数是否下降。可直接 `run_epoch.sh` 拼或仿 `run_exp1.sh` 写 `run_exp2.sh`。
- **实验三（泛化）**：cases 分成 train-split / test-split（**不同任务**），`run_epoch train <train-split>` 后 `run_epoch test <test-split>`，比学习前后 test-split 通过率。

---

## 4. 运维 / 已知坑
- **后台跑 + 定期看**：`nohup ... & disown`；`tail -f tb/runs/exp1/summary.txt`。
- **docker-exec flake / D 态卡死**：极少数情况 agent 会卡在 hung docker-exec（`tb_terminal.py` 已加看门狗兜底到 ~330s；每 case 还有 wall-clock 上限）。若手动中断正在跑的 agent，**别同时 `rm -rf data`**（会把进程搅成 D 态、`kill -9` 都阻塞）。先 `pkill -9 -f tb.runner`、确认进程没了，再清容器（`docker rm -f $(docker ps -aq --filter name=1-of-1)`）和回滚。
- **清残留容器**：`docker rm -f $(docker ps -aq --filter name=1-of-1)`。

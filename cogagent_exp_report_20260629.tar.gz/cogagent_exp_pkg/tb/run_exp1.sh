#!/bin/bash
# run_exp1.sh — Experiment 1 (concept test): does the framework's learning produce
# USABLE knowledge? Train the 7 "finished-but-failed" cases over N epochs and, after
# each train epoch, evaluate the SAME cases in PURE test mode (no learning, no repair)
# to see whether accumulated learning makes them passable.
#
# Protocol:
#   restore seed → TEST epoch e0 (baseline) →
#   for r in 1..N:  TRAIN epoch (learning accumulates) → snapshot → TEST epoch (eval)
#   → print pass-rate matrix across e0,e1,...,eN
#
# Pre-req: a clean seed snapshot exists as `exp1_seed` (bash tb/exp_state.sh fork exp1_seed).
# Usage:   bash tb/run_exp1.sh [N_epochs]      (default 3)
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
N="${1:-3}"
CASES="conda-env-conflict-resolution overfull-hbox modernize-fortran-build mailman vul-flink polyglot-c-py regex-chess"
export EXP_DIR="$PROJECT/tb/runs/exp1"
mkdir -p "$EXP_DIR"; SUM="$EXP_DIR/summary.txt"
echo "############ Exp1 START $(date) | epochs=$N | 7 cases ############" > "$SUM"

# 1) reset to seed
bash tb/exp_state.sh restore exp1_seed >> "$SUM" 2>&1
echo "[seed restored — l2_cards=$($PY -c "import sqlite3;print(sqlite3.connect('data/cognitive/l2.db').execute('select count(*) from l2_cards').fetchone()[0])" 2>/dev/null)]" | tee -a "$SUM"

# 2) baseline test epoch (at seed, before any learning)
bash tb/run_epoch.sh test e0_test "$CASES"

# 3) N rounds of: train epoch → snapshot → test epoch
for r in $(seq 1 "$N"); do
  bash tb/run_epoch.sh train "e${r}_train" "$CASES"
  bash tb/exp_state.sh fork "exp1_after_e${r}_train" 2>&1 | head -1 | tee -a "$SUM"
  echo "  -- learning state after e${r} train --" | tee -a "$SUM"
  "$PY" -m core.learning_track 2>/dev/null | tee -a "$SUM"
  echo "  l2_cards=$($PY -c "import sqlite3;print(sqlite3.connect('data/cognitive/l2.db').execute('select count(*) from l2_cards').fetchone()[0])" 2>/dev/null) l3_skills=$(find data/layers/skills -name SKILL.md 2>/dev/null|wc -l)" | tee -a "$SUM"
  bash tb/run_epoch.sh test "e${r}_test" "$CASES"
done

# 4) results matrix (test-mode pass per case across epochs)
echo "" | tee -a "$SUM"
echo "===== Exp1 RESULTS MATRIX — test-mode PASS/FAIL per case across epochs =====" | tee -a "$SUM"
"$PY" - "$EXP_DIR" "$N" <<'PYEOF' | tee -a "$SUM"
import sys, os
base, N = sys.argv[1], int(sys.argv[2])
labels = ["e0_test"] + [f"e{r}_test" for r in range(1, N + 1)]
def load(lbl):
    p = os.path.join(base, lbl, "results.txt"); d = {}
    if os.path.exists(p):
        for ln in open(p):
            a = ln.split()
            if a: d[a[0]] = a[1] if len(a) > 1 else "?"
    return d
data = {l: load(l) for l in labels}
cases = list(data[labels[0]].keys())
short = [l.replace("_test", "") for l in labels]
print("%-32s " % "case" + " ".join("%-6s" % s for s in short))
for c in cases:
    print("%-32s " % c + " ".join("%-6s" % data[l].get(c, "-") for l in labels))
print("-" * (33 + 7 * len(labels)))
print("%-32s " % "PASS" + " ".join(
    "%-6s" % (f"{sum(1 for c in cases if data[l].get(c)=='PASS')}/{len(cases)}") for l in labels))
PYEOF
echo "############ Exp1 DONE $(date) ############" | tee -a "$SUM"

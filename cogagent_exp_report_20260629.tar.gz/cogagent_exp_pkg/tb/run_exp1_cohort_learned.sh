#!/bin/bash
# run_exp1_cohort_learned.sh — Exp1 cohort LEARNED eval: restore the freshly-
# retrained snapshot (exp1_cohort_after_train, cards in terminal-bench) and run
# bench/pass@3 on the same 9 cohort tasks WITH learning. Compare to the EXISTING
# base pass@3 (3/9, reuse — NOT re-run) and to 1-shot (base 0/9, learned 1/9).
#
# Usage:  bash tb/run_exp1_cohort_learned.sh
# Env:    COHORT_LEARNED_SNAP (default exp1_cohort_after_train), TB_MAX_REPAIRS (default 2)
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
export TB_MAX_REPAIRS="${TB_MAX_REPAIRS:-2}"   # pass@3
unset  TB_DEADLINE_MULT                         # eval = 1.0x (match base)

SNAP="${COHORT_LEARNED_SNAP:-exp1_cohort_after_train}"
CASES="conda-env-conflict-resolution overfull-hbox mailman broken-networking polyglot-c-py write-compressor nginx-request-logging circuit-fibsqrt regex-chess"
EXP="$PROJECT/tb/runs/exp1_cohort_retrain"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
BASE="$PROJECT/tb/runs/exp1_cohort_pass3/cohort_base/results.txt"
log(){ echo "[cohort-learned $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }
_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=?"
import sqlite3
def c(db,t):
    try:return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception:return "?"
print("l1=%s l2=%s l3=%s"%(c("data/cognitive/l1.db","l1_rules"),c("data/cognitive/l2.db","l2_cards"),c("data/cognitive/l3.db","l3_skills")))
PY
}
_clean_all(){
  local ids; ids=$(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null)
  [ -n "$ids" ] && timeout 40 docker rm -f $ids >/dev/null 2>&1
  timeout 30 docker network prune -f >/dev/null 2>&1
  return 0
}

# reaper: rm container running >100min (cohort has heavy circuit/regex tasks)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 6000 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill "$REAPER" 2>/dev/null' EXIT

_clean_all
bash tb/exp_state.sh restore "$SNAP" >/dev/null 2>&1 && log "restored $SNAP ($(_counts)) — cohort LEARNED pass@3 WITH learning" || { log "FATAL restore $SNAP"; exit 1; }
log "=== EXP1 COHORT LEARNED pass@3 (9 tasks, bench/pass@3, WITH learning) — vs base 3/9, 1-shot 1/9 ==="
EXP_DIR="$EXP" bash tb/run_epoch.sh bench cohort_learned "$CASES"
lp=$(grep -c ' PASS' "$EXP/cohort_learned/results.txt" 2>/dev/null)
bp=$(grep -c ' PASS' "$BASE" 2>/dev/null)
log "=== COHORT LEARNED DONE: LEARNED ${lp:-0}/9  vs  BASE ${bp:-0}/9  (1-shot: base 0/9, learned 1/9) ==="
echo "  -- BASE(已有, 无学习) --"   | tee -a "$SUM"; cat "$BASE" 2>/dev/null | sed 's/^/    /' | tee -a "$SUM"
echo "  -- LEARNED(重训后, 带学习) --"| tee -a "$SUM"; cat "$EXP/cohort_learned/results.txt" 2>/dev/null | sed 's/^/    /' | tee -a "$SUM"
kill "$REAPER" 2>/dev/null

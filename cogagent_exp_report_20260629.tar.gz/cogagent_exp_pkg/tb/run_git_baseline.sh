#!/bin/bash
# run_git_baseline.sh — git pass@3 baseline (clean, NO learning)
#   restore exp1_seed -> bench/pass@3 on 5 git tasks -> tb/runs/exp2_git/git_baseline/
#   TB_PHASE=bench (learning OFF, feedback ON), TB_MAX_REPAIRS=2 (=pass@3), 1.0x deadline.
#   This is the clean transfer testbed (logic/reasoning git tasks, no long compiles/boots).
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
export PATH="$PROJECT/.venv/bin:$HOME/.local/bin:$PATH"
export PYTHONPATH="$PROJECT:$PYTHONPATH"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
export TB_MAX_REPAIRS=2          # pass@3 (initial + 2 repair retries)
unset  TB_DEADLINE_MULT          # baseline uses 1.0x

EXP="$PROJECT/tb/runs/exp2_git"; mkdir -p "$EXP"
SUM="$EXP/summary.txt"
GIT_CASES="merge-diff-arc-agi-task git-leak-recovery git-multibranch sanitize-git-repo configure-git-webserver"
log(){ echo "[git-baseline $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }
_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=?"
import sqlite3
def c(db,t):
    try:return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except:return "?"
print("l1=%s l2=%s l3=%s"%(c("data/cognitive/l1.db","l1_rules"),c("data/cognitive/l2.db","l2_cards"),c("data/cognitive/l3.db","l3_skills")))
PY
}

# reaper: kill any 1-of-1 container older than 5400s (insurance backstop)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 5400 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill "$REAPER" 2>/dev/null' EXIT

log "restoring exp1_seed (clean) ..."
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1 && log "restored exp1_seed ($(_counts)) — git baseline NO learning" || { log "FATAL restore exp1_seed"; exit 1; }
log "=== GIT pass@3 BASELINE (5 tasks, bench/pass@3, NO learning, 1.0x) ==="
EXP_DIR="$EXP" bash tb/run_epoch.sh bench git_baseline "$GIT_CASES"
gp=$(grep -c ' PASS' "$EXP/git_baseline/results.txt" 2>/dev/null)
log "=== GIT BASELINE DONE: PASS ${gp:-0}/5 ==="
kill "$REAPER" 2>/dev/null

#!/bin/bash
# smoke_learning.sh — DETERMINISTIC validation of the learning consolidation
# pipeline, independent of the agent: hand-write 5 pending learning cards, run
# the REAL consolidate_runner (executor + LLM), and verify pending drains into
# L1/L2/L3 + archive. Proves "record_learning → pending → consolidate → L1/L2/L3"
# works, before the agent-driven Exp1 smoke (Phase B).
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a
OUT="$PROJECT/tb/runs/exp1_smoke"; mkdir -p "$OUT"
SUM="$OUT/learning_pipeline.log"
log(){ echo "[smoke-learn $(date '+%H:%M:%S')] $*" | tee -a "$SUM"; }
DOM="smoke_test"

_counts(){ "$PY" - 2>/dev/null <<'PY'
import sqlite3,glob
def c(db,t):
    try: return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception: return "?"
print("l1=%s l2=%s l3=%s pending=%d archive=%d" % (
  c("data/cognitive/l1.db","l1_rules"), c("data/cognitive/l2.db","l2_cards"),
  c("data/cognitive/l3.db","l3_skills"),
  len(glob.glob("data/learning/pending/*.json")),
  len(glob.glob("data/archive/**/*.json",recursive=True))))
PY
}
_layernums(){ "$PY" - 2>/dev/null <<'PY'
import sqlite3
def c(db,t):
    try: return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception: return 0
print(c("data/cognitive/l1.db","l1_rules"), c("data/cognitive/l2.db","l2_cards"), c("data/cognitive/l3.db","l3_skills"))
PY
}

log "=== Phase A: consolidation pipeline validation (5 hand-written cards) ==="
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1 || { log "FATAL seed restore"; exit 1; }
log "seed restored: $(_counts)"
read B1 B2 B3 <<<"$(_layernums)"

# 1) hand-write 5 valid pending cards (schema per scripts/test_auto_learning.py)
DOM="$DOM" "$PY" - <<'PY'
import json,os,uuid,datetime
dom=os.environ["DOM"]; os.makedirs("data/learning/pending",exist_ok=True)
lessons=[
 ("从源码构建前先读 README/INSTALL 确认依赖与配置步骤","agent 直接 make 而未先看 INSTALL,缺依赖失败","configure/cmake 依赖应先用包管理器装齐","构建标准流程:探查→装依赖→configure→make→install→验证"),
 ("命令失败时先读完整 stderr 再行动,不要盲目重试","重复执行同一失败命令 3 次而未读错误","编译错误通常直接指出缺失头文件/库","错误诊断:解析报错→定位根因→针对性修复"),
 ("安装到 PATH 后用 which/命令本身验证可执行","声称安装完成但未验证二进制可调用","make install 后应 hash -r 并实际运行一次","交付验证:产物存在性+可执行性+功能性三查"),
 ("写多行文件用 write_file/base64,不要用 heredoc 经 tmux","heredoc 经交互式 shell 卡死无响应","tmux 交互通道不适合传多行内容","安全写文件:单行 base64 落盘避免交互卡死"),
 ("长构建设好预算并分阶段验证,避免最后一刻才发现失败","等到 deadline 才发现 configure 阶段就错了","大型项目构建应阶段性 checkpoint","长任务时间管理:分解里程碑+阶段验证"),
]
for i,(tgt,l1f,l2f,l3f) in enumerate(lessons):
    rec={"id":uuid.uuid4().hex,"domain":dom,"learning_target":tgt,
      "importance":"high" if i<3 else "medium","reasoning":f"smoke 卡 {i}:验证 consolidation 路由",
      "l1_observations":[{"finding":l1f,"evidence":f"round result excerpt {i}","implication":"应纳入 L1 行为准则","relevance":"high"}],
      "l2_observations":[{"finding":l2f,"evidence":f"L2 result {i}","implication":"应建知识卡","relevance":"high"}],
      "l3_observations":[{"finding":l3f,"evidence":f"L3 result {i}","implication":"应建技能","relevance":"high" if i%2==0 else "medium"}],
      "source_rounds":[1],"recorded_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
    json.dump(rec,open(f"data/learning/pending/smoke_{i:02d}.json","w"),ensure_ascii=False,indent=2)
print("wrote 5 pending cards")
PY
log "injected 5 pending cards: $(_counts)"

# 2) run the REAL consolidate_runner (executor + LLM → writes L1/L2/L3)
log "running consolidate_runner --domain $DOM (real LLM, may take 1-3min) ..."
"$PY" -m core.consolidate_runner --domain "$DOM" >> "$OUT/consolidate.log" 2>&1
for i in $(seq 1 120); do pgrep -f core.consolidate_runner >/dev/null || break; sleep 5; done

# 3) verify
read A1 A2 A3 <<<"$(_layernums)"
log "after consolidation: $(_counts)"
PEND=$(ls data/learning/pending/*.json 2>/dev/null | wc -l)
ARCH=$(find data/archive -name '*.json' 2>/dev/null | wc -l)
D1=$((A1-B1)); D2=$((A2-B2)); D3=$((A3-B3)); DT=$((D1+D2+D3))
log "--- VERDICT ---"
[ "$PEND" -eq 0 ] && log "  ✓ pending drained (0)"            || log "  ✗ pending NOT drained ($PEND left)"
[ "$ARCH" -ge 5 ] && log "  ✓ archive populated ($ARCH)"      || log "  ✗ archive missing ($ARCH)"
log "  Δ L1=$D1  L2=$D2  L3=$D3  (total +$DT written)"
[ "$DT" -gt 0 ]   && log "  ✓ learning landed in L1/L2/L3"    || log "  ✗ NOTHING written to L1/L2/L3 — check $OUT/consolidate.log"
log "  newest rows per layer:"
"$PY" - 2>/dev/null <<'PY' | tee -a "$SUM"
import sqlite3
for L,db,t,col in [("L1","data/cognitive/l1.db","l1_rules","content"),
                   ("L2","data/cognitive/l2.db","l2_cards","content"),
                   ("L3","data/cognitive/l3.db","l3_skills","description")]:
    try:
        rows=sqlite3.connect(db).execute(f"select {col} from {t}").fetchall()
        for (x,) in rows[-2:]: print(f"    {L}: "+(x or "")[:95].replace(chr(10)," "))
    except Exception as e: print(f"    {L}: err {e}")
PY
log "=== Phase A done ==="

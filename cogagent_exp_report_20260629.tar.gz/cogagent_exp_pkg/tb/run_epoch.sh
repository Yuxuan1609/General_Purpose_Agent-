#!/bin/bash
# run_epoch.sh — run a set of cases ONCE in a given mode (train|test), sequentially.
# Building block for the learning experiments. Per case:
#   clean stale containers → run (wall-clock capped) → (train: wait for the
#   consolidation subprocess so learning reaches the next case) → record PASS/FAIL.
#
# Usage:  bash tb/run_epoch.sh <train|test> <label> "<case1 case2 ...>"
# Env:    EXP_DIR (output base, default tb/runs/exp)
#         EPOCH_CASE_TIMEOUT (per-case wall-clock cap seconds, default 2400)
# Output: $EXP_DIR/<label>/{<case>.log, results.txt}; appends $EXP_DIR/summary.txt
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
export PATH="$PROJECT/.venv/bin:$HOME/.local/bin:$PATH"
export PYTHONPATH="$PROJECT:$PYTHONPATH"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a

MODE="$1"; LABEL="$2"; CASES="$3"
if [ -z "$MODE" ] || [ -z "$LABEL" ] || [ -z "$CASES" ]; then
  echo "usage: $0 <train|test> <label> \"<cases>\""; exit 1
fi
EXP_DIR="${EXP_DIR:-$PROJECT/tb/runs/exp}"
CAP="${EPOCH_CASE_TIMEOUT:-2400}"
OUT="$EXP_DIR/$LABEL"; mkdir -p "$OUT"
SUM="$EXP_DIR/summary.txt"
: > "$OUT/results.txt"

# TB leaves containers named "<task>-1-of-1-<runid>" (--no-cleanup); match 1-of-1.
_clean(){ local ids; ids=$(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null); [ -n "$ids" ] && timeout 40 docker rm -f $ids >/dev/null 2>&1; return 0; }

# Per-case wall-clock cap = task's max_agent_timeout_sec + margin (test run + 5-min
# timeout-reflection + overhead), floored at $CAP. Hard cases (e.g. regex-chess,
# 3600s agent budget) thus avoid being guillotined before their legitimate budget.
TB_TASKS="${TB_TASKS:-$HOME/tb-tasks/original-tasks}"
# TB_DEADLINE_MULT scales the agent budget (train uses >1 so heavy builds finish
# and generate quality learnings). Default 1.0 = backward-compatible.
MULT="${TB_DEADLINE_MULT:-1.0}"
# Internal agent wall-clock deadline = the task's intended agent budget × MULT. The
# agent self-terminates between rounds at this and returns AGENT_TIMEOUT (tb's own
# asyncio timeout can't interrupt the blocking agent).
_deadline_for(){
  local t="$1" v
  v=$(grep -E '^max_agent_timeout_sec:' "$TB_TASKS/$t/task.yaml" 2>/dev/null | awk '{print $2}' | head -1)
  [ -n "$v" ] || v="${EPOCH_AGENT_DEADLINE:-900}"
  awk -v x="$v" -v m="$MULT" 'BEGIN{printf "%d", int(x*m)}'
}
# Per-case wall-clock cap = deadline + 20-min margin (test run + 5-min timeout-
# reflection + overhead), floored at $CAP. CASE_CAP (external) is the hard backstop.
_cap_for(){
  local t="$1" dl
  dl=$(_deadline_for "$t")
  awk -v d="$dl" -v f="$CAP" 'BEGIN{c=d+1200; printf "%d", (c>f)?c:f}'
}

echo "=== EPOCH [$LABEL] mode=$MODE start $(date '+%m-%d %H:%M:%S') ===" | tee -a "$SUM"
pass=0; n=0
for t in $CASES; do
  n=$((n+1)); _clean; TS=$(date +%s)
  CASE_CAP=$(_cap_for "$t"); CASE_DL=$(_deadline_for "$t")
  echo "  [$LABEL] $t start (deadline=${CASE_DL}s cap=${CASE_CAP}s) $(date '+%H:%M:%S')" | tee -a "$SUM"
  TB_AGENT_DEADLINE_SEC="$CASE_DL" timeout "$CASE_CAP" bash tb/run.sh "$t" "$MODE" > "$OUT/${t}.log" 2>&1 || echo "(run timeout/err)" >> "$OUT/${t}.log"
  # bench/test are read-only: drop any learning records the run leaked (e.g. via
  # sub-agent tools whose writes bypass the main-agent tool-deny). Otherwise they
  # accumulate to >=5 and auto-consolidate into L2/L1 cards mid-run, polluting a
  # supposedly no-learning baseline/eval. Train KEEPS pending (needs to consolidate).
  [ "$MODE" != "train" ] && rm -f data/learning/pending/*.json 2>/dev/null
  # train mode: let the detached consolidation subprocess finish (<=600s) so the
  # learned knowledge is available to the next case
  if [ "$MODE" = "train" ]; then
    for i in $(seq 1 120); do pgrep -f core.consolidate_runner >/dev/null || break; sleep 5; done
  fi
  j=$(find tb/runs -name results.json -newermt "@$TS" -path "*${t}*1-of-1*" 2>/dev/null | head -1)
  res="ERR"
  [ -f "$j" ] && res=$("$PY" -c "import json;d=json.load(open('$j'));print('PASS' if d.get('is_resolved') else 'FAIL')" 2>/dev/null || echo ERR)
  [ "$res" = "PASS" ] && pass=$((pass+1))
  echo "  [$LABEL] $t => $res ($(date '+%H:%M:%S'))" | tee -a "$SUM"
  echo "$t $res" >> "$OUT/results.txt"
done
_clean
echo "  [$LABEL] PASS $pass/$n" | tee -a "$SUM"

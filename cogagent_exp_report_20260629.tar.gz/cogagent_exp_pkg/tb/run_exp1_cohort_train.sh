#!/bin/bash
# run_exp1_cohort_train.sh — Exp1 cohort RETRAIN (clean, current fixed system):
# train the cognitive agent on the 9 Exp1-cohort tasks for N rounds (learning
# accumulates → cards land in terminal-bench naturally via the current pipeline,
# unlike the stale exp1_after_r3 whose cards were in old domains).
# Same-task learning: train on the 9 → later eval (learned pass@3) on the same 9.
#
# Usage:  bash tb/run_exp1_cohort_train.sh
# Env:    COHORT_TRAIN_ROUNDS (default 3), TB_DEADLINE_MULT (default 1.0)
PROJECT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$PROJECT"
PY="$PROJECT/.venv/bin/python"
set -a; source "$PROJECT/.env" 2>/dev/null; set +a

TAG="exp1_cohort_train"
ROUNDS="${COHORT_TRAIN_ROUNDS:-3}"
export TB_DEADLINE_MULT="${TB_DEADLINE_MULT:-1.0}"
CASES="${COHORT_TRAIN_CASES:-conda-env-conflict-resolution overfull-hbox mailman broken-networking polyglot-c-py write-compressor nginx-request-logging circuit-fibsqrt regex-chess}"
NCASE=$(echo $CASES | wc -w)

EXP="$PROJECT/tb/runs/$TAG"; mkdir -p "$EXP" "$PROJECT/tb/runs/_bg"
SUM="$EXP/summary.txt"
log(){ echo "[$TAG $(date '+%m-%d %H:%M:%S')] $*" | tee -a "$SUM"; }

_counts(){ "$PY" - 2>/dev/null <<'PY' || echo "l1=? l2=? l3=? pending=? archive=?"
import sqlite3,glob
def cnt(db,t):
    try: return sqlite3.connect(db).execute(f"select count(*) from {t}").fetchone()[0]
    except Exception: return "?"
print("l1=%s l2=%s l3=%s pending=%d archive=%d" % (
    cnt("data/cognitive/l1.db","l1_rules"),
    cnt("data/cognitive/l2.db","l2_cards"),
    cnt("data/cognitive/l3.db","l3_skills"),
    len(glob.glob("data/learning/pending/*.json")),
    len(glob.glob("data/archive/**/*.json",recursive=True))))
PY
}
_domains(){ "$PY" - 2>/dev/null <<'PY' || echo "    (domain query failed)"
import sqlite3
def dist(db,t):
    try:
        rows=sqlite3.connect(db).execute(f"select domain,count(*) from {t} group by domain order by 2 desc").fetchall()
        return ", ".join(f"{d}:{c}" for d,c in rows) or "(empty)"
    except Exception as e: return f"(err {e})"
print("    L2 domains:", dist("data/cognitive/l2.db","l2_cards"))
PY
}
_drain_pending(){
  for i in $(seq 1 120); do pgrep -f core.consolidate_runner >/dev/null || break; sleep 5; done
  local guard=0
  while [ "$(ls data/learning/pending/*.json 2>/dev/null | wc -l)" -gt 0 ] && [ "$guard" -lt 4 ]; do
    guard=$((guard+1))
    local dom; dom=$("$PY" - 2>/dev/null <<'PY'
import glob,json,collections
d=collections.Counter()
for f in glob.glob("data/learning/pending/*.json"):
    try: d[json.load(open(f)).get("domain","terminal-bench")]+=1
    except Exception: d["terminal-bench"]+=1
print(d.most_common(1)[0][0] if d else "terminal-bench")
PY
)
    log "  drain[$guard]: consolidating pending (domain=$dom) → L1/L2/L3 ..."
    "$PY" -m core.consolidate_runner --domain "$dom" >> "$EXP/consolidate.log" 2>&1
    for i in $(seq 1 120); do pgrep -f core.consolidate_runner >/dev/null || break; sleep 5; done
  done
}
_clean_all(){
  local ids; ids=$(timeout 15 docker ps -aq --filter "name=1-of-1" 2>/dev/null)
  [ -n "$ids" ] && timeout 40 docker rm -f $ids >/dev/null 2>&1
  timeout 30 docker network prune -f >/dev/null 2>&1
  return 0
}

log "START Exp1 cohort RETRAIN  rounds=$ROUNDS  mult=$TB_DEADLINE_MULT  cases=$NCASE"
log "cohort: $CASES"

_clean_all
bash tb/exp_state.sh restore exp1_seed >/dev/null 2>&1 && log "seed restored ($(_counts))" || { log "FATAL seed restore"; exit 1; }
bash tb/exp_state.sh fork exp1_cohort_train_start >/dev/null 2>&1 && log "snapshot exp1_cohort_train_start (clean train start)"

# reaper: rm container running >100min (cohort has heavy circuit/regex tasks, native 3600s)
( while true; do sleep 120; for c in $(timeout 15 docker ps -q --filter "name=1-of-1" 2>/dev/null); do st=$(timeout 10 docker inspect -f '{{.State.StartedAt}}' "$c" 2>/dev/null); [ -n "$st" ]||continue; age=$(( $(date +%s) - $(date -d "$st" +%s 2>/dev/null||date +%s) )); [ "$age" -gt 6000 ] && timeout 30 docker rm -f "$c" >/dev/null 2>&1; done; done ) & REAPER=$!
trap 'kill $REAPER 2>/dev/null' EXIT

for r in $(seq 1 "$ROUNDS"); do
  log "=== TRAIN round $r/$ROUNDS ===  before: $(_counts)"
  _domains | tee -a "$SUM"
  EXP_DIR="$EXP" bash tb/run_epoch.sh train "r$r" "$CASES"
  log "  r$r training done; draining pending → L1/L2/L3 ..."
  _drain_pending
  _clean_all
  bash tb/exp_state.sh fork "${TAG}_after_r$r" >/dev/null 2>&1
  rp=$(grep -c ' PASS' "$EXP/r$r/results.txt" 2>/dev/null)
  log "round $r DONE: train PASS $rp/$NCASE | $(_counts) | snapshot=${TAG}_after_r$r"
  _domains | tee -a "$SUM"
done

_clean_all
bash tb/exp_state.sh fork exp1_cohort_after_train >/dev/null 2>&1 && log "snapshot exp1_cohort_after_train (final learned state)"
log "=== Exp1 cohort RETRAIN DONE === final: $(_counts)"
_domains | tee -a "$SUM"
log "Next: learned pass@3 eval on the same 9 (restore exp1_cohort_after_train) — compare vs base 3/9"

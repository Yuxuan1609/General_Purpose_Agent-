#!/bin/bash
# Pre-build Docker images for the 32 benchmark tasks (Ubuntu port helper).
# Images are named tb__<task-id>__client:latest — the same name the harness
# reuses with --no-rebuild. Re-runnable: skips tasks whose image already exists.
#
# Usage:
#   bash tb/build_images.sh                 # build all 32 (skip existing)
#   FORCE=1 bash tb/build_images.sh         # rebuild even if image exists
#   bash tb/build_images.sh <task-id>...    # build only the given task(s)
#
# Requires: docker access (run under `sg docker -c '...'` if group not active),
#           terminal-bench installed in project venv.
set -u

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [ -x "$PROJECT_ROOT/.venv/bin/tb" ]; then
    TB="$PROJECT_ROOT/.venv/bin/tb"
else
    TB="tb"
fi
DATASET="${TB_DATASET_PATH:-$HOME/tb-tasks/original-tasks}"
LOG_DIR="$PROJECT_ROOT/tb/build-logs"
mkdir -p "$LOG_DIR"

ALL_TASKS=(
    fix-pandas-version conda-env-conflict-resolution incompatible-python-fasttext
    cpp-compatibility classifier-debug swe-bench-fsspec overfull-hbox swe-bench-astropy-1
    fix-git modernize-fortran-build polyglot-c-py broken-python
    pypi-server write-compressor regex-chess circuit-fibsqrt
    fix-permissions processing-pipeline nginx-request-logging log-summary
    broken-networking configure-git-webserver home-server-https mailman
    extract-safely git-workflow-hack openssl-selfsigned-cert sql-injection-attack
    vul-flask crack-7z-hash fix-code-vulnerability vul-flink
)

if [ "$#" -gt 0 ]; then
    TASKS=("$@")
else
    TASKS=("${ALL_TASKS[@]}")
fi

pass=0; fail=0; skip=0
FAILED_TASKS=""
echo "=== Building ${#TASKS[@]} task images (dataset=$DATASET) ==="
for t in "${TASKS[@]}"; do
    img="tb__${t//./-}__client"
    if [ "${FORCE:-0}" != "1" ] && docker image inspect "${img}:latest" >/dev/null 2>&1; then
        echo "[SKIP] $t (image exists)"
        skip=$((skip+1)); continue
    fi
    echo "[BUILD] $t ..."
    if timeout 1800 "$TB" tasks build -t "$t" --tasks-dir "$DATASET" \
            > "$LOG_DIR/${t}.log" 2>&1; then
        if docker image inspect "${img}:latest" >/dev/null 2>&1; then
            echo "  [OK] $t -> ${img}:latest"
            pass=$((pass+1))
        else
            echo "  [FAIL] $t (build returned 0 but image missing) — see $LOG_DIR/${t}.log"
            fail=$((fail+1)); FAILED_TASKS="$FAILED_TASKS $t"
        fi
    else
        echo "  [FAIL] $t (build error/timeout) — see $LOG_DIR/${t}.log"
        fail=$((fail+1)); FAILED_TASKS="$FAILED_TASKS $t"
    fi
done

echo ""
echo "=== Build summary ==="
echo "OK:   $pass"
echo "SKIP: $skip"
echo "FAIL: $fail"
[ -n "$FAILED_TASKS" ] && echo "Failed:$FAILED_TASKS"
echo "Logs: $LOG_DIR"

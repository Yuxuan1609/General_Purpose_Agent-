"""CognitiveAgent — Terminal-Bench BaseAgent implementation.

Wraps the cognitive-agent's Executor + 3-layer chain into TB's BaseAgent
interface. perform_task runs a multi-turn loop:
  1. Build TaskObservation from instruction + initial terminal state
  2. executor.execute(obs) → L1 decides action (may call tools via tmux)
  3. Capture pane → feed back as next observation
  4. Repeat until L1 returns done=True or max rounds reached
"""
from __future__ import annotations
import json
import logging
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from terminal_bench.agents.base_agent import AgentResult, BaseAgent
from terminal_bench.agents.failure_mode import FailureMode

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_MAX_ROUNDS = 30
_INITIAL_PANE_LINES = 50


class CognitiveAgent(BaseAgent):

    @staticmethod
    def name() -> str:
        return "cognitive-agent"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._executor = None
        self._chain = None
        self._setup_done = False
        self._task_meta = ""
        # Persistent conversation transcript for the whole tb-task run. tb-task
        # train is treated as a single interactive session: solving rounds AND
        # the post-test reflection append here, so reflection sees the full
        # trajectory (what was observed + decided) — without this the agent has
        # no record of solving and cannot record a meaningful lesson.
        self._conv_history: list[dict] = []

    def _ensure_setup(self):
        if self._setup_done:
            return
        if str(_PROJECT_ROOT) not in sys.path:
            sys.path.insert(0, str(_PROJECT_ROOT))
        from core.setup import setup_executor
        self._chain, self._executor = setup_executor(_PROJECT_ROOT)

        import os
        phase = os.environ.get("TB_PHASE", "train")
        from tb.env import apply_learning_context
        apply_learning_context(self._chain, enable=(phase == "train"))

        from tb.tools import register_tb_tools
        from core.tools.registry import ToolRegistry
        registry = ToolRegistry()
        register_tb_tools(registry)
        self._setup_done = True

    def _append_turn(self, observation: str, action: str) -> None:
        """Record one interaction turn into the persistent conversation history."""
        obs = (observation or "").strip()
        if obs:
            self._conv_history.append({"role": "user", "content": obs[:1500]})
        act = (action or "").strip()
        if act:
            self._conv_history.append({"role": "assistant", "content": act[:1500]})

    def _history_text(self, max_turns: int = 24) -> str:
        """Format the persistent conversation history (past turns only) for the
        prompt's history section — kept distinct from the current observation."""
        if not self._conv_history:
            return ""
        lines = []
        for h in self._conv_history[-max_turns:]:
            label = "[历史·观察]" if h["role"] == "user" else "[历史·我的决策]"
            lines.append(f"{label}\n{h['content']}")
        return "\n".join(lines)

    def perform_task(
        self,
        instruction: str,
        session,
        logging_dir: Path | None = None,
    ) -> AgentResult:
        t_start = time.time()
        self._ensure_setup()

        from tb.session_holder import set as set_session, clear as clear_session
        set_session(session)

        # Disable pagers so git/man/systemctl output goes straight to the
        # terminal instead of opening an interactive pager (less/$PAGER), which
        # blocks the tmux send_keys mechanism forever — the agent then wedges on
        # the pager until the wall-clock cap (observed: `git show <ref>:<file>`
        # opened /usr/bin/pager and hung at `(END)` for the whole 40min cap).
        # Env exports ALONE proved unreliable: they can be lost if typed before
        # the shell reaches a prompt, so git still paged. We also set
        # `git config --global core.pager cat`, which writes ~/.gitconfig
        # (file-level, persistent) — git never pages regardless of shell env.
        # Settle briefly first so the container shell is at a prompt.
        try:
            time.sleep(0.8)
            session.send_keys(
                ["git config --global core.pager cat; "
                 "export PAGER=cat GIT_PAGER=cat SYSTEMD_PAGER=cat LESS=FRX",
                 "Enter"],
                block=True, max_timeout_sec=15,
            )
        except Exception:
            logger.warning("pager-disable preamble failed", exc_info=True)

        # Setup per-layer file logging (detailed prompts + tool calls → logs/tb/)
        _setup_tb_logging()

        try:
            time.sleep(0.5)
            initial_pane = session.capture_pane(capture_entire=True)
        except Exception:
            initial_pane = ""

        task_meta = (
            f"{instruction}\n\n"
            "## 环境说明\n"
            "你正在一个 Docker 容器内的终端环境中工作。所有文件操作和命令执行"
            "都在容器内进行。\n"
            "使用 terminal 工具执行命令，read_file 读取文件，write_file 创建/覆盖文件，grep 搜索文件内容。\n\n"
            "## terminal 工具使用要点\n"
            "- 每次调用只执行一条 shell 命令（避免 && 串联多条，出错不易定位）\n"
            "- git 命令加 --no-pager 或预先 export PAGER=cat（已自动设置）\n"
            "- 创建/覆盖文件用 write_file(path, content) 工具；不要用 cat << EOF 等 heredoc 写文件（经 tmux 不可靠、易卡死）\n"
            "- 命令执行后检查输出，根据结果决定下一步\n\n"
            "## 完成任务\n"
            "当任务完成时，明确输出 done=true 并在 result 中说明你做了什么。\n"
            "最终 test feedback（任务结束后的自动化测试结果）是 golden standard，"
            "判断任务是否成功的唯一标准。\n\n"
            "## 反思与学习（train 模式）\n"
            "任务结束后会收到测试反馈。PASS 时请反思成功经验，FAIL 时分析失败原因。\n"
            "将可复用的经验通过 record_learning 记录到对应的 domain。\n\n"
            "## terminal-bench 学习域（重要）\n"
            "这是一个 terminal-bench 任务。为让经验能跨任务复用、避免域不匹配导致检索不到，"
            "请把所有相关学习统一组织在 `terminal-bench` 域下（可用子域如 terminal-bench/build、terminal-bench/networking）：\n"
            "- 开始解决任务前，先用 l1_query（domains_hint=[\"terminal-bench\"]）唤起/查询 terminal-bench 域是否已有可复用经验；该域不存在时可用 create_domain 创建。\n"
            "- record_learning 记录时 domain 一律填 `terminal-bench`（或其子域），不要用 interaction 等默认域。\n\n"
        "## 检索到的经验卡片（重要）\n"
        "通过 l1_query / query_domain 等检索到的经验卡片，其 id（形如 card_xxx）仅是认知系统内的记忆标识，"
        "用于 l2_query / l1_query 等认知操作的引用；它**不是容器里的文件路径**——"
        "切勿用 read_file / grep / terminal 去搜索 card_xxx 或卡片 id（这些文件根本不存在，只会浪费时间、触发全盘慢搜索并可能卡死终端）。"
        "直接使用返回结果中 content 字段里的经验内容即可。"
        )
        self._task_meta = task_meta
        self._conv_history = []

        import os
        _deadline_sec = float(os.environ.get("TB_AGENT_DEADLINE_SEC", "0") or "0")
        _deadline = (t_start + _deadline_sec) if _deadline_sec > 0 else None
        _hit_deadline = False

        current_feedback = _trim_pane(initial_pane, _INITIAL_PANE_LINES)

        # Reset LLM token counters
        llm = self._executor._llm
        llm.reset_token_counts()
        round_logs: list[dict] = []

        logger.info("=== Task started ===")
        logger.info("Instruction: %s", instruction[:200])
        logger.info("Initial pane (%d lines):\n%s",
                     len(initial_pane.splitlines()) if initial_pane else 0,
                     _head(initial_pane, 500))

        for round_idx in range(_MAX_ROUNDS):
            if _deadline is not None and time.time() > _deadline:
                logger.warning(
                    "Internal wall-clock deadline (%.0fs) reached at round %d — "
                    "stopping solving so tests + reflection can run",
                    _deadline_sec, round_idx)
                _hit_deadline = True
                break
            t_round = time.time()
            obs = self._build_observation(task_meta, current_feedback, round_idx,
                                          history=self._history_text())

            try:
                result = self._executor.execute(obs)
            except Exception as e:
                logger.error("Executor failed at round %d: %s", round_idx, e)
                clear_session()
                return AgentResult(
                    total_input_tokens=llm._prompt_tokens,
                    total_output_tokens=llm._completion_tokens,
                    failure_mode=FailureMode.UNKNOWN_AGENT_ERROR,
                )

            notify = result.get("notify_layers", {})
            l1_notify = notify.get("l0_5_1", {})
            done = l1_notify.get("done", False)
            action_text = str(result.get("action_text", ""))[:500]

            # Record this round (observation seen + action taken) into the
            # persistent interactive-session history for later rounds + reflection.
            self._append_turn(current_feedback, action_text)

            elapsed = time.time() - t_round
            tokens_so_far = llm.total_tokens
            logger.info(
                "Round %d: done=%s tokens=%d time=%.1fs action=%s",
                round_idx, done, tokens_so_far, elapsed, action_text[:120],
            )

            round_log = {
                "round": round_idx,
                "done": done,
                "elapsed_s": round(elapsed, 2),
                "tokens_total": tokens_so_far,
                "action_text": action_text,
                "l1_notify": {
                    k: str(v)[:300] for k, v in l1_notify.items()
                },
            }
            round_logs.append(round_log)

            if logging_dir:
                self._log_round(logging_dir, round_idx, result, done, elapsed,
                                tokens_so_far)

            time.sleep(0.5)
            try:
                pane = session.capture_pane(capture_entire=True)
                current_feedback = _trim_pane(pane, _INITIAL_PANE_LINES)
            except Exception:
                current_feedback = "(无法读取终端输出)"

            if done:
                logger.info("Task done at round %d (total tokens=%d time=%.1fs)",
                            round_idx, tokens_so_far, time.time() - t_start)
                break
        else:
            logger.warning("Reached max rounds (%d) without done signal", _MAX_ROUNDS)

        total_time = time.time() - t_start
        clear_session()

        if logging_dir:
            self._log_summary(logging_dir, round_logs, llm, total_time)

        # If we stopped because the internal wall-clock deadline was hit (rather
        # than completing), report AGENT_TIMEOUT so FeedbackHarness runs the
        # timeout reflection (record_learning over the solving history).
        failure_mode = FailureMode.AGENT_TIMEOUT if _hit_deadline else FailureMode.NONE
        return AgentResult(
            total_input_tokens=llm._prompt_tokens,
            total_output_tokens=llm._completion_tokens,
            failure_mode=failure_mode,
        )

    def _build_observation(self, task_meta: str, feedback: str, round_idx: int,
                           history: str = ""):
        from core.types import TaskObservation
        return TaskObservation(
            meta=task_meta,
            state={
                "current": feedback,
                "history": history,
                "round": round_idx,
            },
            session={
                "id": f"tb_{round_idx}",
                "domain": "terminal-bench",
                "domains_hint": ["terminal-bench"],
                "step_index": round_idx,
                "enable_learning": True,
            },
        )

    _REPAIR_MAX_ROUNDS = 15
    _REFLECT_MAX_ROUNDS = 5

    def receive_test_results(
        self,
        parser_results: dict | None,
        is_resolved: bool,
        exhausted: bool,
        session,
        terminal,
        timed_out: bool = False,
    ) -> None:
        """Called by FeedbackHarness after tests, while container is still alive."""
        from tb.session_holder import set as set_session, clear as clear_session

        set_session(session)

        try:
            time.sleep(0.3)
            pane = session.capture_pane(capture_entire=True)
        except Exception:
            pane = ""

        feedback_meta = self._build_feedback_meta(
            parser_results, is_resolved, exhausted, timed_out
        )
        current_feedback = _trim_pane(pane, _INITIAL_PANE_LINES)

        max_rounds = (
            self._REFLECT_MAX_ROUNDS
            if (is_resolved or exhausted)
            else self._REPAIR_MAX_ROUNDS
        )
        deadline = None
        if timed_out:
            # Timeout reflection: tight, record_learning-only, 5-min wall-clock cap.
            max_rounds = min(max_rounds, 2)
            deadline = time.monotonic() + 300

        logger.info(
            "=== Test feedback === is_resolved=%s exhausted=%s max_rounds=%d",
            is_resolved, exhausted, max_rounds,
        )

        for round_idx in range(max_rounds):
            if deadline is not None and time.monotonic() > deadline:
                logger.info("Timeout reflection: 5-min window elapsed, stopping")
                break
            obs = self._build_observation(feedback_meta, current_feedback, round_idx,
                                          history=self._history_text())
            try:
                result = self._executor.execute(obs)
            except Exception as e:
                logger.error("Executor failed in feedback round %d: %s", round_idx, e)
                break

            notify = result.get("notify_layers", {})
            l1_notify = notify.get("l0_5_1", {})
            done = l1_notify.get("done", False)
            action_text = str(result.get("action_text", ""))[:500]

            self._append_turn(current_feedback, action_text)

            logger.info(
                "Feedback round %d: done=%s action=%s",
                round_idx, done,
                str(result.get("action_text", ""))[:120],
            )

            time.sleep(0.3)
            try:
                pane = session.capture_pane(capture_entire=True)
                current_feedback = _trim_pane(pane, _INITIAL_PANE_LINES)
            except Exception:
                current_feedback = "(无法读取终端输出)"

            if done:
                break

        clear_session()

    def _build_feedback_meta(
        self,
        parser_results: dict | None,
        is_resolved: bool,
        exhausted: bool,
        timed_out: bool = False,
    ) -> str:
        """Build task meta for the feedback phase."""
        results_text = "（无测试结果）"
        if parser_results:
            lines = []
            for test_name, status in parser_results.items():
                lines.append(f"  {test_name}: {status.value}")
            results_text = "\n".join(lines)

        if timed_out:
            phase = (
                "## 任务超时中止\n\n"
                "任务因执行超时被中止，说明当前方案/能力存在需要优化的地方。\n"
                "你现在【只能且必须】调用 record_learning 记录这次超时的教训：\n"
                "- 卡在了哪一步、为什么会超时（方案低效 / 反复试错 / 缺少关键技能或知识）\n"
                "- 下次遇到类似任务应如何更快完成或避免超时\n"
                "【不要】执行任何其他操作：不要调用 terminal、不要 web 搜索、不要尝试修复。\n"
                "记录完成后立即输出 done=true。\n"
            )
        elif is_resolved:
            phase = (
                "## 测试结果: PASS\n\n"
                "所有测试通过。请反思成功经验：\n"
                "- 哪些策略/命令有效\n"
                "- 哪些知识卡片/技能有帮助\n"
                "反思完成后，调用 record_learning 记录可复用经验，"
                "然后输出 done=true。\n"
            )
        elif exhausted:
            phase = (
                "## 测试结果: FAIL（已用尽修复次数）\n\n"
                "所有修复轮次已用完，任务未通过。请反思失败原因：\n"
                "- 哪里出了问题\n"
                "- 下次遇到类似任务该如何避免\n"
                "反思完成后，调用 record_learning 记录教训，"
                "然后输出 done=true。\n"
            )
        else:
            phase = (
                "## 测试结果: FAIL\n\n"
                "测试未通过。请分析失败原因，修复问题。\n"
                "- 使用 terminal/read_file/grep 工具检查文件和状态\n"
                "- 修复后输出 done=true 表示修复完成\n"
            )

        return (
            f"{self._task_meta}\n\n"
            f"{phase}\n"
            f"### 测试详情\n{results_text}\n"
        )

    def _log_round(self, logging_dir: Path, round_idx: int,
                   result: dict, done: bool, elapsed: float, tokens: int):
        log_path = logging_dir / f"round_{round_idx}.json"
        try:
            notify_summary = {}
            for k, v in result.get("notify_layers", {}).items():
                notify_summary[k] = {
                    kk: str(vv)[:500] for kk, vv in v.items()
                }
            log_path.write_text(json.dumps({
                "round": round_idx,
                "done": done,
                "elapsed_s": round(elapsed, 2),
                "tokens_total": tokens,
                "action_text": str(result.get("action_text", ""))[:2000],
                "notify_layers": notify_summary,
            }, ensure_ascii=False, indent=2))
        except Exception:
            pass

    def _log_summary(self, logging_dir: Path, round_logs: list[dict],
                     llm, total_time: float):
        summary_path = logging_dir / "summary.json"
        try:
            summary_path.write_text(json.dumps({
                "agent": "cognitive-agent",
                "completed_at": datetime.now(timezone.utc).isoformat(),
                "total_time_s": round(total_time, 1),
                "total_rounds": len(round_logs),
                "prompt_tokens": llm._prompt_tokens,
                "completion_tokens": llm._completion_tokens,
                "total_tokens": llm.total_tokens,
                "rounds": round_logs,
            }, ensure_ascii=False, indent=2))
        except Exception:
            pass


def _trim_pane(pane: str, max_lines: int) -> str:
    lines = pane.splitlines()
    if len(lines) <= max_lines:
        return pane
    return "\n".join(lines[-max_lines:])


def _head(text: str, n: int) -> str:
    return text[:n] + ("..." if len(text) > n else "")


def _setup_tb_logging():
    """Create per-layer DEBUG log files under logs/tb/<timestamp>/.

    Reuses the same logging infrastructure as interactive_agent.py via
    setup_layer_logging. Creates: l0_5_1.log, l2.log, l3.log, executor.log
    with full prompt and tool-call detail.
    """
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_dir = _PROJECT_ROOT / "logs" / "tb" / stamp
    from core.layers.logging_setup import setup_layer_logging
    setup_layer_logging(log_dir)

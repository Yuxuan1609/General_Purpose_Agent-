"""Lightweight track for record_learning — call count + downstream status only.

record_learning is the core of the learning system (KB is just one downstream
sink). This module records, append-only, one JSON line per event to
``data/learning/record_learning_track.jsonl`` (override via env
``LEARNING_TRACK_PATH``).

Design:
- Best-effort: tracking must NEVER raise into the learning flow.
- Concurrency-safe across processes: each event is a single short ``O_APPEND``
  line (atomic <PIPE_BUF on POSIX), so parallel tb task processes can share one
  file without a cross-process lock.

Events:
- ``call``        — record_learning was invoked (the call count)
- ``downstream``  — terminal status of that call's downstream processing
                    (``ok`` | ``fill_failed`` | ``error``)
- ``auto_learning`` — the batched consolidation escalation (``triggered`` | ``ok``)
"""
from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

_DEFAULT = "data/learning/record_learning_track.jsonl"
_lock = threading.Lock()


def _path() -> Path:
    return Path(os.environ.get("LEARNING_TRACK_PATH", _DEFAULT))


def _clip(s, n=120):
    return s[:n] if isinstance(s, str) else s


def _emit(event: str, **fields) -> None:
    try:
        rec = {"ts": datetime.now(timezone.utc).isoformat(), "event": event}
        rec.update({k: v for k, v in fields.items() if v is not None})
        line = json.dumps(rec, ensure_ascii=False, default=str) + "\n"
        p = _path()
        with _lock:
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "a", encoding="utf-8") as f:
                f.write(line)
    except Exception:
        # Tracking is observability-only; never break the learning flow.
        pass


def track_call(target=None, importance=None, mode=None) -> None:
    """record_learning was invoked (counts toward the call count)."""
    _emit("call", target=_clip(target), importance=importance, mode=mode)


def track_downstream(status: str, rec_id=None, target=None) -> None:
    """Terminal status of a record_learning call's downstream processing.

    status: ``ok`` | ``fill_failed`` | ``error``
    """
    _emit("downstream", status=status, id=rec_id, target=_clip(target))


def track_auto_learning(status: str) -> None:
    """Downstream auto-learning / consolidation escalation.

    status: ``triggered`` | ``ok``
    """
    _emit("auto_learning", status=status)


def summarize(path=None) -> dict:
    """Aggregate the track file into call count + downstream status tallies."""
    p = Path(path) if path else _path()
    calls = 0
    downstream: dict[str, int] = {}
    auto: dict[str, int] = {}
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            ev = r.get("event")
            if ev == "call":
                calls += 1
            elif ev == "downstream":
                s = r.get("status", "?")
                downstream[s] = downstream.get(s, 0) + 1
            elif ev == "auto_learning":
                s = r.get("status", "?")
                auto[s] = auto.get(s, 0) + 1
    return {"calls": calls, "downstream": downstream,
            "auto_learning": auto, "file": str(p)}


if __name__ == "__main__":
    import sys
    s = summarize(sys.argv[1] if len(sys.argv) > 1 else None)
    fmt = lambda d: ", ".join(f"{k}={v}" for k, v in sorted(d.items())) or "(none)"
    print(f"record_learning calls: {s['calls']}")
    print(f"downstream status:     {fmt(s['downstream'])}")
    print(f"auto_learning:         {fmt(s['auto_learning'])}")
    print(f"file: {s['file']}")

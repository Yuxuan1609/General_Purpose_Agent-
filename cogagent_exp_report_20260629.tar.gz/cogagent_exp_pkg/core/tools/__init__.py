"""Unified tool registration — single mount point for all tools."""
from pathlib import Path


def register_all_tools(registry, proposal_dir: Path | None = None):
    """Register all core tools onto the given ToolRegistry.

    Args:
        registry: ToolRegistry singleton.
        proposal_dir: Directory for tool_proposal output. If None, proposals
                      are returned in response but not saved to disk.
    """
    from core.tools.terminal_tool import register_terminal_tool
    from core.tools.web_search_tool import register_tavily_search_tool
    from core.tools.file_tools import register_read_file, register_grep
    from core.tools.tool_proposal import register_tool_proposal, set_proposal_dir
    from core.tools.kb_tools import register_kb_tools
    from core.tools.async_tools import register_async_tools
    from core.tools.consolidation_tools import register_consolidation_tools

    register_terminal_tool(registry)
    register_tavily_search_tool(registry)
    register_read_file(registry)
    register_grep(registry)
    register_tool_proposal(registry)
    register_kb_tools(registry)
    register_async_tools(registry)
    register_consolidation_tools(registry)
    from core.tools.sysinfo_tool import register_sysinfo_tool
    register_sysinfo_tool(registry)

    from core.tools.record_learning_tool import register_record_learning
    register_record_learning(registry)

    from core.tools.downward_comm_tool import register_downward_tools
    register_downward_tools(registry)

    from core.tools.secondary_tool import register_secondary_tool
    register_secondary_tool(registry)

    if proposal_dir:
        set_proposal_dir(proposal_dir)

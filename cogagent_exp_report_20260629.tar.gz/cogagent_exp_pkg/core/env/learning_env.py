from __future__ import annotations
import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from core.env.base import Environment, EnvState, EnvStep
from core.env.threshold_scorer import ThresholdScorer
from core.types import TaskObservation

logger = logging.getLogger(__name__)

# ── Consolidation spec loader ──────────────────────────────────────────

def load_consolidation_spec(spec_path: Path | str | None = None) -> dict:
    """Load consolidation spec from config.yaml (consolidation section).

    Args:
        spec_path: Ignored (kept for backward compatibility). Spec is read
                   from get_section('consolidation').

    Returns:
        dict with per-layer entry specs, limits, and consolidation strategies.
    """
    from core.config_loader import get_section
    spec = get_section('consolidation', default={})
    if spec:
        logger.debug("Loaded consolidation spec from config.yaml: %s", list(spec.keys()))
    else:
        logger.debug("Consolidation spec not found in config.yaml, using defaults")
    return spec

# Per-layer output format — each layer checks its key in state and merges
# the field schema into its JSON output. Field descriptions reference
# the existing knowledge format for that layer.
_L1_OUTPUT: dict = {
    "type": "object",
    "properties": {
        "response": {
            "type": "object",
            "properties": {
                "result": {"type": "string"},
                "reasoning": {"type": "string"},
            },
            "required": ["result", "reasoning"],
        },
        "notify": {
            "type": "object",
            "properties": {
                "l1_modifications": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "target": {"type": "string"},
                            "type": {"type": "string", "enum": ["update", "create", "deprecate"]},
                            "payload": {
                                "type": "object",
                                "properties": {
                                    "content": {"type": "string"},
                                    "reason": {"type": "string"},
                                },
                                "required": ["content", "reason"],
                            },
                        },
                        "required": ["target", "type"],
                    },
                },
            },
        },
    },
    "required": ["response"],
}

_L2_OUTPUT: dict = {
    "type": "object",
    "properties": {
        "response": {
            "type": "object",
            "properties": {
                "reply": {"type": "string"},
                "cards": {"type": "array", "items": {"type": "string"}},
                "reasoning": {"type": "string"},
            },
            "required": ["reply", "reasoning"],
        },
        "notify": {
            "type": "object",
            "properties": {
                "l2_modifications": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "target": {"type": "string"},
                            "type": {"type": "string", "enum": ["update", "create", "deprecate"]},
                            "payload": {
                                "type": "object",
                                "properties": {
                                    "content": {"type": "string"},
                                    "reason": {"type": "string"},
                                    "domain": {"type": "string"},
                                    "confidence": {"type": "number"},
                                },
                                "required": ["content", "reason"],
                            },
                        },
                        "required": ["target", "type"],
                    },
                },
            },
        },
    },
    "required": ["response"],
}

_L3_OUTPUT: dict = {
    "type": "object",
    "properties": {
        "response": {
            "type": "object",
            "properties": {
                "result": {"type": "string"},
                "skills_used": {"type": "array", "items": {"type": "string"}},
                "reasoning": {"type": "string"},
            },
            "required": ["result", "reasoning"],
        },
        "notify": {
            "type": "object",
            "properties": {
                "l3_modifications": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "target": {"type": "string"},
                            "type": {"type": "string", "enum": ["update", "create", "deprecate"]},
                            "payload": {
                                "type": "object",
                                "properties": {
                                    "content": {"type": "string"},
                                    "reason": {"type": "string"},
                                    "domain": {"type": "string"},
                                },
                                "required": ["content", "reason"],
                            },
                        },
                        "required": ["target", "type"],
                    },
                },
            },
        },
    },
    "required": ["response"],
}


def _now_iso():
    return datetime.now(timezone.utc).isoformat()


class LearningEnv(Environment):
    """Learning environment — consumes ExecutionRecords, produces knowledge changes.

    Shares Executor + Layers + ToolUse with GameEnv. Learning is modeled as
    a standard env: observation = pending records as LearningUnits,
    action = Agent's per-layer NOTIFY with modifications,
    step = parse NOTIFY layers → validate → apply → record stats.

    Agent decides WHAT to change; LearningEnv executes HOW and tracks usage.
    """

    def __init__(self, pending_dir: Path, knowledge_stores: dict,
                 preprocessing_llm=None,
                 l2_card_limit: int | None = None,
                 l3_skill_limit: int | None = None,
                 dry_run: bool = False,
                 consolidation_spec: dict | None = None,
                 domain_registry=None):
        self._pending_dir = Path(pending_dir)
        self._knowledge = knowledge_stores
        self._registry = domain_registry
        self._pre_llm = preprocessing_llm
        self._scorer = ThresholdScorer(pending_dir)
        self._dry_run = dry_run

        # Consolidation spec — loaded from YAML or passed directly
        self._consolidation_spec = consolidation_spec or load_consolidation_spec()
        l2_soft = self._consolidation_spec.get('l2', {}).get('limits', {}).get('soft')
        l3_soft = self._consolidation_spec.get('l3', {}).get('limits', {}).get('soft')
        self._l2_limit = l2_card_limit if l2_card_limit is not None else (l2_soft if l2_soft is not None else 25)
        self._l3_limit = l3_skill_limit if l3_skill_limit is not None else (l3_soft if l3_soft is not None else 15)

        self._pending_records: list[dict] = []
        self._enriched_units: list[dict] = []
        self._step_count: int = 0
        self._done: bool = False
        self._current_observation: str = ""
        self._base_domain: str = "general"

        # Per-layer reverse-notify feedback — populated by step(),
        # consumed by build_task_observation() / build_consolidation_task().
        # feedback (shared, read by all layers) + lX_feedback (per-layer).
        self._shared_feedback: str = ""
        self._layer_feedback: dict[str, str] = {}

    # ── public API ──────────────────────────────────────────────────────

    def reset(self, task_description: str) -> EnvState:
        domain = self._extract_domain(task_description)
        self._base_domain = domain

        records = self._scan_pending(domain)
        if not records:
            self._pending_records = []
            self._done = True
            return EnvState(observation="")

        self._pending_records = records
        self._step_count = 0
        self._done = False

        learning_units = self._build_learning_units(records)
        self._enriched_units = learning_units
        review = self._build_per_layer_review(learning_units, domain)
        self._current_observation = review["meta"]
        return EnvState(observation=review["meta"])

    def step(self, action: str) -> EnvStep:
        self._step_count += 1
        self._done = True
        self._shared_feedback = "学习轮次完成（修改由工具 handler 直接改库）"
        self._layer_feedback = {"l1": "", "l2": "", "l3": ""}
        return EnvStep(
            state=EnvState(observation=self._shared_feedback),
            reward=0.0, done=True)

    def apply_modifications(self, notify_layers: dict) -> EnvStep:
        self._step_count += 1
        self._done = True
        self._shared_feedback = "学习轮次完成（修改由工具 handler 直接改库）"
        self._layer_feedback = {"l1": "", "l2": "", "l3": ""}
        return EnvStep(
            state=EnvState(observation=self._shared_feedback),
            reward=0.0, done=True)

    # ── observation building ────────────────────────────────────────────

    def build_task_observation(self) -> TaskObservation | None:
        if not self._current_observation:
            return None

        units = getattr(self, '_enriched_units', self._pending_records)
        review = self._build_per_layer_review(units, self._base_domain)
        history = self._build_conversation_history(units)

        return TaskObservation(
            meta=review["meta"],
            state={
                "current": review["meta"],
                "history": history,
                "learning_units": units,
                "l1_output_format": _L1_OUTPUT,
                "l2_output_format": _L2_OUTPUT,
                "l3_output_format": _L3_OUTPUT,
                "l1_task": review["l1_task"],
                "l2_task": review["l2_task"],
                "l3_task": review["l3_task"],
                "feedback": self._shared_feedback,
                "l1_feedback": self._layer_feedback.get("l1", ""),
                "l2_feedback": self._layer_feedback.get("l2", ""),
                "l3_feedback": self._layer_feedback.get("l3", ""),
            },
            session={
                "domain": self._base_domain,
                "domains_hint": ["learning/reflect", self._base_domain],
                "id": f"learning_{self._step_count}",
                "step_index": self._step_count,
                "enable_learning": False,
            },
        )

    def build_consolidation_task(self) -> TaskObservation | None:
        l2 = self._knowledge.get("l2")
        l3 = self._knowledge.get("l3")
        l1_rules = self._knowledge.get("l1")

        # ── Build triggered domain lists (DD1: capacity trigger) ──
        spec = self._consolidation_spec

        l2_triggers: dict[str, str] = {}
        l3_triggers: dict[str, str] = {}
        from collections import Counter
        all_domains: set[str] = set()
        domain_counts: Counter[str] = Counter()
        skill_domain_counts: Counter[str] = Counter()

        # L2: capacity check (only when over limit) + maintenance check (always)
        if l2:
            for c in l2.cards:
                domain_counts[c.domain.path] += 1
                all_domains.add(c.domain.path)
            for domain, count in domain_counts.items():
                if count > self._l2_limit:
                    l2_triggers[domain] = "capacity"

        # L3: capacity check
        if l3:
            for s in l3.list_all():
                skill_domain_counts[s.domain.path] += 1
                all_domains.add(s.domain.path)
            for domain, count in skill_domain_counts.items():
                if count > self._l3_limit:
                    l3_triggers[domain] = "capacity"

        if not l2_triggers and not l3_triggers:
            return None

        level = self.get_consolidation_level()
        level_info = spec.get("consolidation_levels", {}).get(level, {}) if spec else {}

        # ── meta: per-layer review — states what each layer should review ──
        meta_lines = [
            "## Knowledge Consolidation Task",
            f"Level {level} — {level_info.get('label', '整理')}.",
            "",
        ]

        # L1 review
        if l1_rules and hasattr(l1_rules, 'all_rules'):
            rule_count = len([r for r in l1_rules.all_rules() if r.source == "l1"])
            if rule_count > 0:
                meta_lines.append(f"- **L1 Rules**: {rule_count} rule(s) to review. "
                                  f"Check for duplicates, domain-specific content, vague rules.")
        else:
            meta_lines.append("- **L1 Rules**: no review needed.")

        # L2 review
        if l2_triggers:
            meta_lines.append(f"- **L2 Cards**: review needed. "
                              f"Triggered domains: {', '.join(sorted(l2_triggers.keys()))}.")
        else:
            meta_lines.append("- **L2 Cards**: no review needed.")

        # L3 review
        if l3_triggers:
            meta_lines.append(f"- **L3 Skills**: review needed. "
                              f"Triggered domains: {', '.join(sorted(l3_triggers.keys()))}.")
        else:
            meta_lines.append("- **L3 Skills**: no review needed.")

        meta_lines.append("")
        meta_lines.append("Each layer has its own sub-task details in state. "
                          "Layer agents should read meta above to decide whether to query downstream layers.")

        # Per-domain detail (informational)
        if l2_triggers:
            meta_lines.append("")
            meta_lines.append("### L2 Cards — triggered domains")
            for domain, count in sorted(domain_counts.items()):
                if domain not in l2_triggers:
                    continue
                over = count - self._l2_limit
                meta_lines.append(
                    f"- **{domain}**: {count} cards (overflow — {over} over limit {self._l2_limit}). "
                    f"Reduce to below {self._l2_limit} via merge/deprecate."
                )
            meta_lines.append("")
        if l3_triggers:
            meta_lines.append("### L3 Skills — triggered domains")
            for domain, count in sorted(skill_domain_counts.items()):
                if domain not in l3_triggers:
                    continue
                over = count - self._l3_limit
                meta_lines.append(
                    f"- **{domain}**: {count} skills (overflow — {over} over limit {self._l3_limit}). "
                    f"Reduce to below {self._l3_limit} via deprecate/compile."
                )
            meta_lines.append("")
        meta = "\n".join(meta_lines)

        if self._registry:
            health = self._scorer.domain_health_report(
                self._registry,
                self._knowledge.get("l2"),
                self._knowledge.get("l3"),
            )
            meta += f"\n\n{health}"

        # ── l1_task: criteria text only (DD4 — no rule listing, system prompt has rules) ──
        l1_task = (
            "## L1 Task\n\n"
            "Review your behavior rules in the system prompt against the criteria below.\n\n"
            "### Judgment Criteria\n"
            "- **deprecate**: duplicate rules (semantic similarity > 80%), domain-specific content "
            "(should belong to L2), vague rules (< 20 chars with no specific directive), "
            "violates cross-domain methodology principle\n"
            "- **modify**: merge multiple rules into one while preserving complete semantics; "
            "also use modify to update usefulness/misleading/comment for rules "
            "that were helpful or misleading during reflection\n"
            "- **create**: only for new cross-domain methodology not achievable via modify\n\n"
            "Use tools: deprecate_l1_rule / create_l1_rule / modify_l1_rule"
        )

        # ── l2_task: criteria only — L2 gets cards from L1's selected_nodes ──
        l2_task = json.dumps({
            "criteria": (
                "### Judgment Criteria\n"
                "- **deprecate**: used=0 + content appears to be placeholder/experimental, "
                "content semantically > 80% similar to another card (keep higher-quality one)\n"
                "- **modify**: merge >= 2 similar cards in same domain into one refined card; "
                "also use modify to update usefulness/misleading/comment for cards "
                "that were helpful or misleading during reflection\n"
                "- **create**: cross-domain generalization (multiple similar cards -> one higher-level card)"
            ),
        }, ensure_ascii=False)

        # ── l3_task: criteria only — L3 gets skills from L2's selected_nodes ──
        l3_task = json.dumps({
            "criteria": (
                "### Judgment Criteria\n"
                "- **deprecate**: never matched/used (use_count=0), vague content, "
                "functionally overlaps with another skill\n"
                "- **modify**: add missing process steps, update outdated instructions; "
                "also use modify to update usefulness/misleading/comment\n"
                "- **create**: compile >= 3 high-activation same-domain cards into SKILL.md "
                "(write full YAML frontmatter + Markdown procedure)"
            ),
        }, ensure_ascii=False)

        hint_domains = ["learning/compile"] + sorted(all_domains)

        return TaskObservation(
            meta=meta,
            state={
                "current": "Consolidation task — see per-layer tasks below",
                "history": "",
                "l1_output_format": _L1_OUTPUT,
                "l2_output_format": _L2_OUTPUT,
                "l3_output_format": _L3_OUTPUT,
                "l1_task": l1_task,
                "l2_task": l2_task,
                "l3_task": l3_task,
                "feedback": self._shared_feedback,
                "l1_feedback": self._layer_feedback.get("l1", ""),
                "l2_feedback": self._layer_feedback.get("l2", ""),
                "l3_feedback": self._layer_feedback.get("l3", ""),
            },
            session={
                "domain": "learning/compile",
                "domains_hint": list(dict.fromkeys(hint_domains)),
                "id": f"consolidation_{self._step_count}",
                "step_index": 0,
                "enable_learning": False,
            },
        )

    # ── consolidation monitoring ────────────────────────────────────────

    def needs_consolidation(self) -> bool:
        """Check if any layer exceeds its capacity limit.

        Triggers when L2 cards or L3 skills exceed configured thresholds.
        """
        l2 = self._knowledge.get("l2")
        if l2 and len(l2.cards) > self._l2_limit:
            logger.info("Consolidation needed: L2 cards=%d > limit=%d",
                        len(l2.cards), self._l2_limit)
            return True

        l3 = self._knowledge.get("l3")
        if l3 and len(l3.list_all()) > self._l3_limit:
            logger.info("Consolidation needed: L3 skills=%d > limit=%d",
                        len(l3.list_all()), self._l3_limit)
            return True

        return False

    def get_consolidation_level(self) -> int:
        """Return consolidation intensity based on overflow severity.

        1 = mild (routine cleanup) — 1-5 items over limit
        2 = deep (aggressive merge/prune) — >5 items over limit
        """
        level = 0
        l2 = self._knowledge.get("l2")
        if l2:
            over = len(l2.cards) - self._l2_limit
            level = max(level, 2 if over > 5 else (1 if over > 0 else 0))
        l3 = self._knowledge.get("l3")
        if l3:
            over = len(l3.list_all()) - self._l3_limit
            level = max(level, 2 if over > 5 else (1 if over > 0 else 0))
        return level

    def archive_pending(self) -> int:
        import shutil
        domain_dir = self._pending_dir / self._base_domain.replace("/", "_")
        if not domain_dir.exists():
            return 0
        learned_dir = (
            self._pending_dir.parent / "learned" /
            self._base_domain.replace("/", "_"))
        learned_dir.mkdir(parents=True, exist_ok=True)
        moved = 0
        for f in sorted(domain_dir.glob("*.json")):
            shutil.move(str(f), str(learned_dir / f.name))
            moved += 1
        logger.info("Archived %d pending file(s) -> %s", moved, learned_dir)
        return moved

    def process_in_memory(self, records: list[dict], domain: str):
        """Build learning TaskObservation from in-memory record_learning records.

        Skips LLM1 preprocessing. Formats records as '任务1: json1 ... 任务N: jsonN'.
        Keeps L1/L2/L3 output schemas so consolidation tools are triggered.
        """
        task_texts = []
        for i, rec in enumerate(records, 1):
            task_texts.append(f"任务{i}:\n{json.dumps(rec, ensure_ascii=False, indent=2)}")

        meta = (
            f"## 自动学习任务 — {domain}\n\n"
            f"从 {len(records)} 条记录中学习。\n\n\n"
            + "\n\n".join(task_texts)
        )

        l1_task = (
            "## L1 Learning Task\n\n"
            "基于以上记录分析行为准则是否存在缺陷或改进机会。\n\n"
            "### Judgment Criteria\n"
            "- **deprecate**: duplicate rules, domain-specific content (→L2), vague rules\n"
            "- **modify**: merge multiple rules, update usefulness/misleading/comment\n"
            "- **create**: new cross-domain methodology\n\n"
            "Use tools: deprecate_l1_rule / create_l1_rule / modify_l1_rule"
        )

        l2_task = json.dumps({
            "criteria": (
                f"### Context\n{domain} records.\n\n"
                "### Judgment Criteria\n"
                "- **deprecate**: unused/placeholder cards, >80% semantic overlap\n"
                "- **modify**: merge similar cards, update usefulness/misleading/comment\n"
                "- **create**: cross-domain generalization from multiple similar cards\n\n"
                "Use tools: deprecate_l2_card / create_l2_card / modify_l2_card"
            ),
        }, ensure_ascii=False)

        l3_task = json.dumps({
            "criteria": (
                f"### Context\n{domain} records.\n\n"
                "### Judgment Criteria\n"
                "- **deprecate**: never matched/used skills, vague content\n"
                "- **modify**: add missing process steps, update outdated instructions\n"
                "- **create**: compile cards into SKILL.md (YAML + Markdown)\n\n"
                "Use tools: deprecate_l3_skill / create_l3_skill / modify_l3_skill"
            ),
        }, ensure_ascii=False)

        session_id = f"learning_auto_{_now_iso().replace(':', '-')[:19]}"
        return TaskObservation(
            meta=meta,
            state={
                "current": meta,
                "history": "",
                "learning_units": records,
                "l1_output_format": _L1_OUTPUT,
                "l2_output_format": _L2_OUTPUT,
                "l3_output_format": _L3_OUTPUT,
                "l1_task": l1_task,
                "l2_task": l2_task,
                "l3_task": l3_task,
                "feedback": "",
                "l1_feedback": "",
                "l2_feedback": "",
                "l3_feedback": "",
            },
            session={
                "domain": domain,
                "domains_hint": ["learning/reflect", domain],
                "id": session_id,
                "step_index": 0,
                "enable_learning": False,
            },
        )

    def _build_learning_units(self, records: list[dict]) -> list[dict]:
        """Phase 2.2: LLM preprocess when available, else heuristic fallback."""
        if self._pre_llm is not None:
            try:
                return self._build_learning_units_llm(records)
            except Exception as e:
                logger.warning("LLM1 preprocessing failed, using heuristic: %s", e)
        return self._build_learning_units_heuristic(records)

    def _build_learning_units_llm(self, records: list[dict]) -> list[dict]:
        """LLM1: enrich raw records with structured per-layer reasoning."""
        cap = min(len(records), 20)
        summaries = []
        for i, rec in enumerate(records[:cap]):
            session = rec.get("session", {})
            notify = rec.get("notify_layers", {})
            l1_n = notify.get("l0_5_1", {})
            l2_n = notify.get("l2", {})
            summaries.append({
                "idx": i,
                "session_id": session.get("id", ""),
                "step": session.get("step_index", 0),
                "action": rec.get("action", ""),
                "l1_result": l1_n.get("result", ""),
                "l1_reasoning": str(l1_n.get("reasoning", ""))[:200],
                "l2_cards_used": str(l2_n.get("cards_used", []))[:200],
                "l3_skills": str(
                    [s.get("name", "") if isinstance(s, dict) else str(s)
                     for s in notify.get("l3", {}).get("skills_used", [])]
                ),
            })

        prompt = (
            "You are a learning data preprocessor. Convert raw game execution "
            "records into structured LearningUnits. For each record, extract:\n"
            "- summary: one-line description of what happened and why\n"
            "- l1_reasoning: what L1 rule/principle drove the decision\n"
            "- l2_reasoning: what L2 knowledge cards informed the decision\n"
            "- l3_reasoning: what L3 skills contributed\n\n"
            f"Records:\n{json.dumps(summaries, ensure_ascii=False, indent=2)}\n\n"
            "Return a JSON array of objects with fields: "
            "idx, summary, l1_reasoning, l2_reasoning, l3_reasoning."
        )
        logger.debug("── LLM1 Preprocess ──")
        logger.debug("  records: %d, prompt chars: %d", cap, len(prompt))
        logger.debug("  prompt:\n%s", prompt[:3000])
        resp = self._pre_llm.chat(
            messages=[{"role": "user", "content": prompt}],
            json_mode=True,
        )
        text = resp.text if hasattr(resp, 'text') else str(resp)
        enriched = json.loads(text)
        if not isinstance(enriched, list):
            enriched = []

        enriched_map = {e.get("idx", e.get("index", -1)): e for e in enriched}
        units = []
        for i in range(len(records)):
            rec = records[i]
            enrich = enriched_map.get(i, {})
            session = rec.get("session", {})
            notify = rec.get("notify_layers", {})
            units.append({
                "index": i,
                "session_id": session.get("id", "unknown"),
                "domain": session.get("domain", "general"),
                "action": str(rec.get("action", "")),
                "result": str(notify.get("l0_5_1", {}).get("result", "")),
                "reasoning": enrich.get("summary", "") or
                    str(notify.get("l0_5_1", {}).get("reasoning", ""))[:200],
                "step": session.get("step_index", 0),
                "l1_reasoning": enrich.get("l1_reasoning", ""),
                "l2_reasoning": enrich.get("l2_reasoning", ""),
                "l3_reasoning": enrich.get("l3_reasoning", ""),
            })
        return units

    def _build_conversation_history(self, units: list[dict]) -> str:
        records = self._pending_records
        if not records:
            return "（无历史记录）"
        lines = []
        for rec in records:
            obs = rec.get("observation", {})
            state = obs.get("state", {}) if isinstance(obs, dict) else {}
            user_input = state.get("current", "")
            notify = rec.get("notify_layers", {})
            l1 = notify.get("l0_5_1", {})
            model_reply = l1.get("result", "")
            if user_input:
                lines.append(f"[用户]: {str(user_input)[:300]}")
            if model_reply:
                lines.append(f"[模型]: {str(model_reply)[:300]}")
            lines.append("---")
        return "\n".join(lines)

    def _build_learning_units_heuristic(self, records: list[dict]) -> list[dict]:
        units = []
        for i, rec in enumerate(records):
            session = rec.get("session", {})
            notify = rec.get("notify_layers", {})
            l1_notify = notify.get("l0_5_1", {})
            units.append({
                "index": i,
                "session_id": session.get("id", "unknown"),
                "domain": session.get("domain", "general"),
                "action": str(rec.get("action", "")),
                "result": str(l1_notify.get("result", "")),
                "reasoning": str(l1_notify.get("reasoning", ""))[:200],
                "step": session.get("step_index", 0),
            })
        return units

    def _build_per_layer_review(self, units: list[dict], domain: str) -> dict:
        """Aggregate LLM1 enrichment into per-layer review.

        LLM1 outputs per-record l1/l2/l3_reasoning.
        We aggregate these into layer-specific summaries — no judgment, only grouping.
        """
        l1_notes = [(u["index"], u["l1_reasoning"])
                     for u in units if u.get("l1_reasoning")]
        l2_notes = [(u["index"], u["l2_reasoning"])
                     for u in units if u.get("l2_reasoning")]
        l3_notes = [(u["index"], u["l3_reasoning"])
                     for u in units if u.get("l3_reasoning")]

        l1_has = bool(l1_notes)
        l2_has = bool(l2_notes)
        l3_has = bool(l3_notes)

        meta = (
            f"## Learning Task — {domain}\n\n"
            f"从 {len(units)} 条执行记录中学习。\n\n"
            f"- **L1 Rules**: {'review needed.' if l1_has else 'no review needed.'}\n"
            f"- **L2 Cards**: {'review needed.' if l2_has else 'no review needed.'}\n"
            f"- **L3 Skills**: {'review needed.' if l3_has else 'no review needed.'}\n\n"
            f"Layer agents should read above to decide whether to query downstream layers. "
            f"Each layer has its own task in state with detailed criteria."
        )

        l1_task = (
            f"## L1 Learning Task\n\n"
            f"基于以下执行记录分析行为准则是否存在缺陷或改进机会。\n\n"
            f"### 相关记录\n" +
            "\n".join(f"[{i}] {r[:300]}" for i, r in l1_notes if r) if l1_notes else "（无）" +
            f"\n\n### Judgment Criteria\n"
            f"- **deprecate**: rules that were irrelevant or harmful in these games\n"
            f"- **modify**: refine a rule that was helpful but could be improved\n"
            f"- **create**: new cross-domain methodology discovered\n\n"
            f"Use tools: deprecate_l1_rule / create_l1_rule / modify_l1_rule"
        )

        l2_task = json.dumps({
            "criteria": (
                f"### Context\n{domain} game records. "
                f"{len(l2_notes)} card-related observations.\n\n"
                f"### Judgment Criteria\n"
                f"- **create**: new strategic pattern, create a knowledge card\n"
                f"- **modify**: existing card needs update based on results\n"
                f"- **deprecate**: card was used but ineffective\n\n"
                f"Use tools: deprecate_l2_card / create_l2_card / modify_l2_card"
            ),
        }, ensure_ascii=False)

        l3_task = json.dumps({
            "criteria": (
                f"### Context\n{domain} game records. "
                f"{len(l3_notes)} skill-related observations.\n\n"
                f"### Judgment Criteria\n"
                f"- **create**: compile patterns into a reusable skill\n"
                f"- **modify**: update existing skill\n"
                f"- **deprecate**: skill was misleading or unused\n\n"
                f"Use tools: deprecate_l3_skill / create_l3_skill / modify_l3_skill"
            ),
        }, ensure_ascii=False)

        return {"meta": meta, "l1_task": l1_task, "l2_task": l2_task, "l3_task": l3_task}

    # ── utilities ────────────────────────────────────────────────────────

    def _extract_domain(self, task_description: str) -> str:
        desc_lower = task_description.lower()
        for keyword, domain in [
            ("leduc", "game/leduc"),
            ("doudizhu", "game/doudizhu"),
            ("coding", "coding"),
            ("learn", "learning/reflect"),
        ]:
            if keyword in desc_lower:
                return domain
        return desc_lower

    def _scan_pending(self, domain: str) -> list[dict]:
        records = []
        domain_dir = self._pending_dir / domain.replace("/", "_")
        if not domain_dir.exists():
            return records
        for f in sorted(domain_dir.glob("*.json")):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                records.extend(data if isinstance(data, list) else [data])
            except (json.JSONDecodeError, OSError):
                logger.warning("Failed to read pending record: %s", f)
        return records

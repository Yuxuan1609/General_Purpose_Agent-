from __future__ import annotations
from dataclasses import dataclass, field


@dataclass
class FunctionCall:
    name: str
    arguments: str = "{}"


@dataclass
class ToolCall:
    id: str
    function: FunctionCall


@dataclass
class LLMResponse:
    text: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    prompt_tokens: int = 0
    completion_tokens: int = 0

    @property
    def has_tool_calls(self) -> bool:
        return len(self.tool_calls) > 0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


class LLMClient:
    def __init__(self, client, model: str):
        self._client = client
        self.model = model
        self.thinking_enabled = False
        self._prompt_tokens = 0
        self._completion_tokens = 0

    @property
    def total_tokens(self) -> int:
        return self._prompt_tokens + self._completion_tokens

    def reset_token_counts(self) -> None:
        self._prompt_tokens = 0
        self._completion_tokens = 0

    def chat(self, messages: list, tools: list | None = None,
             json_mode: bool = False, **kwargs) -> LLMResponse:
        params = {"model": self.model, "messages": messages}
        if json_mode:
            params["response_format"] = {"type": "json_object"}
        if getattr(self, "thinking_enabled", False):
            extra = params.setdefault("extra_body", {})
            thinking = extra.setdefault("thinking", {})
            thinking["type"] = "enabled"
            if hasattr(self, "thinking_effort"):
                thinking["effort"] = self.thinking_effort
        params.update(kwargs)
        if tools:
            params["tools"] = [
                {"type": "function", "function": t["function"]}
                if isinstance(t, dict) and "function" in t else t
                for t in tools
            ]
        # Stream so the client-level read timeout acts as an idle/no-progress
        # timeout (gap between tokens) rather than a flat total — long but
        # progressing calls stay alive; a truly hung response fails fast.
        params["stream"] = True
        params["stream_options"] = {"include_usage": True}
        content_parts: list[str] = []
        tool_acc: dict[int, dict] = {}
        usage = None
        for chunk in self._client.chat.completions.create(**params):
            cu = getattr(chunk, "usage", None)
            if cu is not None:
                usage = cu
            choices = getattr(chunk, "choices", None) or []
            if not choices:
                continue
            delta = choices[0].delta
            if getattr(delta, "content", None):
                content_parts.append(delta.content)
            for tc in (getattr(delta, "tool_calls", None) or []):
                acc = tool_acc.setdefault(tc.index, {"id": "", "name": "", "arguments": ""})
                if getattr(tc, "id", None):
                    acc["id"] = tc.id
                fn = getattr(tc, "function", None)
                if fn is not None:
                    if getattr(fn, "name", None):
                        acc["name"] = fn.name
                    if getattr(fn, "arguments", None):
                        acc["arguments"] += fn.arguments

        prompt_tokens = usage.prompt_tokens if usage else 0
        completion_tokens = usage.completion_tokens if usage else 0
        self._prompt_tokens += prompt_tokens
        self._completion_tokens += completion_tokens
        tool_calls = [
            ToolCall(
                id=acc["id"],
                function=FunctionCall(name=acc["name"], arguments=acc["arguments"] or "{}"),
            )
            for _idx, acc in sorted(tool_acc.items())
        ]
        return LLMResponse(
            text="".join(content_parts),
            tool_calls=tool_calls,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        )

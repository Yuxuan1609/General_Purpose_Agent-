from __future__ import annotations
import json
import logging
import uuid
from pathlib import Path
from typing import Any

from core.types import TaskObservation, ExecutionRecord
from core.layers.base import _indent

logger = logging.getLogger(__name__)


class Executor:
    """Independent decision-maker outside the layer system.

    Responsibilities:
      1. Send QUERY down the layer chain
      2. Wait for RESPONSE chain to complete
      3. Collect NOTIFY from all layers
      4. Assemble final prompt from all layer contexts
      5. Call LLM and return action
      6. Optionally write ExecutionRecord to learning pipeline

    Executor does NOT send messages back to layers (只收不发).
    """

    def __init__(self, layer_root, llm_client, learning_dir: Path | None = None,
                 max_tokens: int | None = None, temperature: float | None = None):
        self._root = layer_root
        self._llm = llm_client
        self._learning_dir = learning_dir
        from core.config_loader import get_section
        ex = get_section('executor', default={})
        self._max_tokens = max_tokens if max_tokens is not None else ex.get('max_tokens', 512)
        self._temperature = temperature if temperature is not None else ex.get('temperature', 0.1)
        self._session_files: dict[str, Path] = {}  # session_id → filepath

    def execute(self, obs: TaskObservation) -> dict:
        """Execute one action cycle through the cognitive chain.

        L1's decide() produces the final decision. Executor uses it directly;
        LLM fallback only when L1 doesn't output a valid result.
        """
        session = obs.session or {}
        step = session.get("step_index", 0)
        domain = session.get("domain", "")
        logger.debug("══════ Step %d  [%s] ══════", step, domain)
        trace_id = uuid.uuid4().hex[:12]
        self._root.query(obs, trace_id=trace_id)
        notify_layers = self._root.collect_notify()

        # Use L1's result as the final action.
        # L1's decide() returns {done, result, reasoning} via NOTIFY.
        # Executor formats output without substantive reasoning.
        # TODO: Future complex tasks may need an extra LLM formatting call.
        l1_notify = notify_layers.get("l0_5_1", {})
        logger.debug("══════ Step %d  [%s] ══════", step, domain)
        logger.debug("── Assembled NOTIFY ──")
        for layer_name in ("l0_5_1", "l2", "l3"):
            layer_notify = notify_layers.get(layer_name, {})
            if not layer_notify:
                continue
            label = layer_name.replace("l0_5_1", "L1").replace("l2", "L2").replace("l3", "L3")
            logger.debug("  %s: %s", label, json.dumps(layer_notify, ensure_ascii=False, default=str))
        if l1_notify.get("done") and "result" in l1_notify:
            action_text = l1_notify["result"]
            logger.debug("  Executor action: %s", action_text)
        else:
            logger.debug("  L1 result unavailable, falling back to LLM")
            context = self._assemble_context(obs)
            action_text = self._call_llm(context)

        result = {
            "action_text": action_text,
            "notify_layers": notify_layers,
        }

        # _write_pending is deprecated — Agent uses record_learning tool instead.
        # Learning records are now written by record_learning → pending dir.
        # if self._learning_dir and session.get("enable_learning", True):
        #     self._write_pending(obs, notify_layers, result)

        return result

    def _assemble_context(self, obs: TaskObservation) -> dict:
        return {
            "meta": obs.meta,
            "state": obs.state,
        }

    def _call_llm(self, context: dict) -> str:
        system = self._build_system_prompt(context)
        user = self._build_user_prompt(context)
        state = context.get("state", {})
        l1_count = len(state.get("l1_rules", []))
        l2_count = len(state.get("l2_cards", []))
        l3_count = len(state.get("l3_skills", []))
        logger.debug("── Executor ──")
        logger.debug("  context: l1=%d l2=%d l3=%d",
                     l1_count, l2_count, l3_count)
        logger.debug("  system:\n%s", _indent(system, 4))
        logger.debug("  user:\n%s", _indent(user, 4))
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        resp = self._llm.chat(messages=messages)
        action_text = resp.text if hasattr(resp, 'text') else str(resp)
        logger.info("[Executor] action: %s", action_text)
        logger.debug("── end Executor ──\n")
        return action_text

    def _build_system_prompt(self, context: dict) -> str:
        meta = context.get("meta", "")
        state = context.get("state", {})
        rules = state.get("l1_rules", [])
        cards = state.get("l2_cards", [])
        skills = state.get("l3_skills", [])

        parts = []
        if meta:
            parts.append("[任务说明]\n" + meta)
        if rules:
            parts.append("[行为准则]\n" + "\n".join(f"- {r}" for r in rules))
        if cards:
            parts.append(
                "[相关知识]\n" +
                "\n".join(
                    f"- [{c['domain']}] {c['content']} (confidence:{c['confidence']:.1f})"
                    for c in cards
                )
            )
        if skills:
            skill_lines = []
            for s in skills:
                skill_lines.append(f"## {s['name']}: {s['description']}")
                if s.get("content"):
                    skill_lines.append(s["content"])
            parts.append("[可用技能]\n" + "\n".join(skill_lines))
        return "\n\n".join(parts) if parts else ""

    def _build_user_prompt(self, context: dict) -> str:
        state = context.get("state", {})
        parts = []
        history = state.get("history", "")
        if history:
            parts.append(f"[对局历史]\n{history}")
        current = state.get("current", "")
        if current:
            parts.append(current)
        return "\n\n".join(parts) if parts else ""

    def write_game_result(self, session_id: str, domain: str, result: dict) -> None:
        """Write game-end summary to session's pending file (no agent call)."""
        if not self._learning_dir:
            return
        task_dir = self._learning_dir / "pending" / domain.replace("/", "_")
        task_dir.mkdir(parents=True, exist_ok=True)

        if session_id not in self._session_files:
            return
        filepath = self._session_files[session_id]
        if not filepath.exists():
            return

        existing: list = []
        try:
            existing = json.loads(filepath.read_text(encoding="utf-8"))
            if not isinstance(existing, list):
                existing = [existing]
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to read pending file %s: %s", filepath, e)
            return

        existing.append({"type": "game_end", **result})

        import tempfile
        tmp = tempfile.mktemp(suffix=".json", dir=str(task_dir))
        content = json.dumps(existing, ensure_ascii=False, indent=2, default=str)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(content)
        Path(tmp).replace(filepath)

"""Standalone consolidation runner — runs auto-learning consolidation in its
own process.

Spawned (detached) by ``record_learning_tool._spawn_consolidation`` when pending
learning records reach the trigger threshold. Running consolidation in a fresh
process — instead of an async task inside the (possibly ephemeral) host process —
fixes two failures seen when it ran inside a Terminal-Bench task process:

* ``cannot schedule new futures after shutdown`` — the host process's thread
  pool is torn down on exit while consolidation still dispatches sub-tasks.
* terminal tools timing out (up to 300s each) against a dead tmux session,
  because the consolidation layer chain had task-solving tools available.

This process has its own live thread pool, loads its own executor via
``setup_executor`` (which also ``register_runtime`` so ``get_executor`` works),
and denies the task-solving / terminal tools so consolidation only touches
L1/L2/L3 + KB. A file lock enforces single-flight so concurrent triggers (e.g.
parallel-train) don't run overlapping consolidations.

Usage:
    python -m core.consolidate_runner --domain interaction
"""
from __future__ import annotations

import argparse
import fcntl
import logging
import os
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Task-solving / terminal / recursion-prone tools the consolidation must NOT use.
# Consolidation should only touch L1/L2/L3 + KB via the consolidation/kb tools.
_DENIED_TOOLS = {
    "terminal", "web_search", "tavily_search", "read_file", "grep",
    "tool_proposal", "sysinfo", "ask_user", "check_task", "collect_tasks",
    "activate_secondary_tools", "record_learning",
}


def _apply_consolidation_context(chain) -> None:
    """Deny task-solving tools on every layer (same mechanism as tb/env.py)."""
    from core.agent_context import AgentContext
    ctx = AgentContext(denied_tools=set(_DENIED_TOOLS))
    node = chain
    while node is not None:
        agent = getattr(node, "_agent", None)
        if agent is not None:
            agent.set_context(ctx)
        node = getattr(node, "_downstream", None)


def main() -> None:
    parser = argparse.ArgumentParser(description="Standalone learning consolidation")
    parser.add_argument("--domain", default="interaction")
    args = parser.parse_args()

    os.chdir(_PROJECT_ROOT)  # relative data/ paths must resolve from project root
    if str(_PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(_PROJECT_ROOT))

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    log = logging.getLogger("consolidate_runner")

    # Optional detailed per-layer logs (prompts + tool calls) for debugging.
    if os.environ.get("CONSOLIDATE_DEBUG_LOGS"):
        try:
            from datetime import datetime
            from core.layers.logging_setup import setup_layer_logging
            dbg_dir = (_PROJECT_ROOT / "data" / "learning" / "consolidate_logs"
                       / datetime.now().strftime("%Y%m%d_%H%M%S"))
            setup_layer_logging(dbg_dir)
            log.info("detailed consolidation logs → %s", dbg_dir)
        except Exception:
            log.exception("failed to enable detailed consolidation logs")

    pending_path = _PROJECT_ROOT / "data" / "learning" / "pending"
    lock_path = _PROJECT_ROOT / "data" / "learning" / ".consolidate.lock"
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    # Single-flight: if another consolidation holds the lock, exit immediately.
    lock_file = open(lock_path, "w")
    try:
        fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        log.info("another consolidation is already running — exiting")
        lock_file.close()
        return

    try:
        files = sorted(pending_path.glob("*.json"))
        if not files:
            log.info("no pending records — nothing to consolidate")
            return

        log.info("consolidating %d pending record(s) for domain=%s",
                 len(files), args.domain)

        from core.setup import setup_executor
        chain, _executor = setup_executor(_PROJECT_ROOT)
        _apply_consolidation_context(chain)

        from core.tools.record_learning_tool import _dispatch_learning
        from core.learning_track import track_auto_learning
        try:
            _dispatch_learning(args.domain, pending_path, files)
            log.info("consolidation finished")
        except Exception:
            log.exception("consolidation failed")
            track_auto_learning("failed")
    finally:
        try:
            fcntl.flock(lock_file, fcntl.LOCK_UN)
        except OSError:
            pass
        lock_file.close()


if __name__ == "__main__":
    main()

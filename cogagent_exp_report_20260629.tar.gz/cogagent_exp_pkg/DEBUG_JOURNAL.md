# Project Debug Journal — cognitive-agent

> 更新原则：记录本项目解决的复杂 Bug。保持 ≤10000 字。
> **格式**：症状 → 根因 → 解决方案 → 可迁移经验。
> **触发条件**：每次解决耗时超过预期或需要深层分析的 Bug 后更新。

---

## 2026-05 开发阶段 — 尚无复杂 Bug 记录

（框架搭建阶段，71 个测试全绿。后续遇到复杂 Bug 在此记录。）

---

## 2026-06-26 TB 移植后实战修复（并发/超时/IO 一组 Bug）

### B1. LLM 调用无超时 → agent 挂死约 10 分钟（最深根因）
**症状**：跑任务时 agent 卡在某轮 LLM 调用 4–10min 不返回；tb 的 agent 超时（60s/120s）压根不触发；随后报 "executor did not finishing joining its threads within 300s"，最终被外层 CAP 砍成 ERR、无 record_learning。
**根因**：`core/llm_factory.py` 构造 `OpenAI()` 未传 `timeout`/`max_retries` → 用 SDK 默认 600s。一次尾延迟/挂起的 DeepSeek 调用就阻塞调用线程 ~10min；线程卡在 socket 上，tb 的 asyncio 超时打不断、线程池 join 不掉。
**解决方案**：改 **流式 + 空闲(读)超时**。`OpenAI(timeout=httpx.Timeout(connect=15,read=60,write=30,pool=15), max_retries=...)`，`llm_client.chat` 改 `stream=True` 累积 content/tool_calls/usage。`read` 即"token 间空闲超时"：持续吐 token 不超时（合法慢调用 OK），连续 60s 无 token 才快速失败。config 可调 `idle_timeout`/`max_retries`。
**可迁移经验**：外部 API 客户端必须显式设超时；扁平"总超时"分不清"慢但在进展"与"挂死"，**流式 + 空闲(读)超时**才是对的粒度。

### B2. tb 的 agent 超时无法中断阻塞的 agent
**症状**：设 `--global-agent-timeout-sec 60/120`，agent 跑几分钟也不触发超时。
**根因**：tb 用 `asyncio.run(wait_for(loop.run_in_executor(perform_task), timeout))`。`run_in_executor` 的 future **不可取消**——线程一旦在跑就跑到底，`wait_for` 超时停不掉它 = 等于没有有效超时。
**解决方案**：`perform_task` 内部加 **wall-clock deadline**（`TB_AGENT_DEADLINE_SEC`），每轮间检查、超了干净 return `AGENT_TIMEOUT` → FeedbackHarness 照常跑测试+反思。agent 自管预算；准时返回也让 executor 线程正常结束、顺带消除 300s join 挂死。
**可迁移经验**：超时得由"能真正停下来的人"执行——同步阻塞任务要**自己在安全点查 deadline**，别指望外部 cancel。

### B3. heredoc 经 tmux 写文件卡死
**症状**：agent 用 `cat > f << EOF ...` 写多行文件时整轮卡死（~330s 看门狗兜底），polyglot 等"写文件"任务天天 ERR。
**根因**：TB 用 `tmux send-keys` **模拟键盘逐行打字**跑命令，靠追加 `; tmux wait -S done` 判完成。heredoc 多行+状态机：任一行没敲对/`EOF` 没精确单独成行，shell 永停在 heredoc 输入态，完成标记被当 heredoc 内容吞掉 → 永不返回。agent 又无写文件工具，只能用 heredoc。
**解决方案**：新增 `write_file(path,content)`（`tb/tools/tb_write_file.py`）：内容 **base64 编码成安全单行** `printf %s '<b64>' | base64 -d > path`（大文件分块 append），复用 send_keys 阻塞发送。单行=无 heredoc/无特殊字符 → 整类卡死消失。提示词改"写文件用 write_file、勿用 heredoc"。验证：polyglot 由 ERR→PASS。
**可迁移经验**：经"模拟打字终端"跑命令要避开多行/状态机构造；把不可控内容压成一条 base64 安全单行最稳。

### B4. 反思 history 为空 → 无法 record_learning
**症状**：超时/失败后的反思阶段，agent 不写 record_learning，反而继续跑 terminal 解题。
**根因**：`perform_task` 的解题轨迹 `_history` 是局部变量、返回即丢；`receive_test_results`（反思）从 `_history=""` 重新开始 → agent 在 prompt 里看不到"刚才做了什么" → 无从反思、只能重新摸索。
**解决方案**：把 tb-task train 当作**一个 interactive session**（仿 `InteractionEnv`）：持久 `self._conv_history`（user=观察/assistant=决策），经 `obs.state["history"]` 喂给各轮+反思；反思承接解题轨迹。提示词 `[历史·...]` 与 `[当前局面]` 分明。状态树(RoundHistory) 不动，仍由 record_learning 独立快照。
**可迁移经验**：多阶段 agent 的"反思/学习"必须拿到前序轨迹；跨阶段上下文共享是前提不是可选。

### 其他修复
- web_search（SearXNG localhost:8765 未起 → Connection refused 刷屏+收尾挂）：下掉 `web_search` 注册，改用 **Tavily**（质量实测高），3 层提示词 + tools.yaml 同步。
- SQLite WAL 各 store 补 `busy_timeout=5000`（并发写兜底）。
- L1/L2 提示词加判据：**终端命令报错并定位/修复 → record_learning**。
- `run_epoch.sh`：per-case `CAP` 与 `TB_AGENT_DEADLINE_SEC` 均按 task.yaml `max_agent_timeout_sec` 推导。

---

<!-- 模板：
## [日期] [Bug 简述]

**症状**：[观察到什么异常？错误信息？行为偏差？]

**根因**：[底层原因是什么？哪个模块/函数的什么逻辑导致？]

**解决方案**：[怎么修的？改了什么？为什么这样修？]

**可迁移经验**：[从这个 Bug 学到什么通用的教训？]
-->
